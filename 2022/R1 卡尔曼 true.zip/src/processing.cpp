#include "processing.h"
using namespace cv;
using namespace std;

int dmin = 1, dmax = 90;//(*100)
int lowH = 7, highH = 13;
int lowS = 100, highS = 255;
int lowV = 50, highV = 200;

int roundness_H = 900 ,roundness_L = 660;//(为圆度乘以1000，滑条创建从0到1000)
int linearity_H = 520,linearity_L=400;//(为线度除以100，滑条创建从0到1000)
				
Mat maskc,maskd;

int stateNum =6;//detect six states :depth center.x and center.y,and the change of them
int measureNum = 3;//measure three states :depth center.x and center.y

Point2f precenter;

int R_x = 116; int R_y = 116;int R_d = 70;/*varaince divide by 1e+4*/ 
int Q = 100;/*varaince divide by 1e+*/ 

static KalmanFilter KF(stateNum,measureNum,0);
float delta_t = (float)1/(float)FramePerSecond;
static Mat prediction = (Mat_<float>(6, 1) << (0,0,0,0,0,0));//the predicted position 
static Mat measurement = (Mat_<float>(3, 1) << 0,0,0);//initialize the z'(0) for updating later

float stablize(Point center,float radius,cv::Mat & transformed_depth_frame);

void trackbars()
{
    namedWindow("trackbar");
	createTrackbar("min", "trackbar", &dmin, 100);
	createTrackbar("max", "trackbar", &dmax, 100);

	createTrackbar("highH", "trackbar", &highH, 180);
	createTrackbar("lowH", "trackbar", &lowH, 180);
	createTrackbar("highS", "trackbar", &highS, 255);
	createTrackbar("lowS", "trackbar", &lowS, 255);
	createTrackbar("highV", "trackbar", &highV, 255);
	createTrackbar("lowV", "trackbar", &lowV, 255);

	namedWindow("trackbar_RL");
	createTrackbar("roundness_H", "trackbar_RL", &roundness_H, 1000);
	createTrackbar("roundness_L", "trackbar_RL", &roundness_L, 1000);
	createTrackbar("linearity_H", "trackbar_RL", &linearity_H, 1000);
	createTrackbar("linearity_L", "trackbar_RL", &linearity_L, 1000);

	namedWindow("KalmanFilter");
	createTrackbar("R(x)", "KalmanFilter", &R_x, 1000);
	createTrackbar("R(y)", "KalmanFilter", &R_y, 1000);
	createTrackbar("R(d)", "KalmanFilter", &R_d,1000);
	createTrackbar("Q(x)", "KalmanFilter", &Q, 1000);
}
void initialize()
{
	KF.statePost = (Mat_<float>(6, 1) <<0,0,0,0,0,0);//initialize the three states in maskc.
	KF.transitionMatrix = (Mat_<float>(6, 6) << 1,0,0,1,0,0,0,1,0,0,1,0
	,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,1);//state transition matrix (A)
	KF.measurementNoiseCov = (Mat_<float>(3,3)<<(float)R_x/(float)E4,0,0,0,(float)R_y/(float)E4,0,0,0,(float)R_d/(float)E4);//Param 2: measurement noise covariance matrix (R)
	setIdentity(KF.processNoiseCov);KF.processNoiseCov=((float)Q/(float)E4)*KF.processNoiseCov; // Param 1 : process noise covariance matrix (Q)
	setIdentity(KF.measurementMatrix);//measurement matrix (H)
	setIdentity(KF.errorCovPost);KF.errorCovPost=10*KF.errorCovPost;// posteriori error estimate covariance matrix P(k)
	//cout<<"Q(k):    "<<KF.processNoiseCov<<endl;
	//cout<<"R(k):   "<<KF.measurementNoiseCov<<endl;
	//With time pass by,the P(k) will be updated closing to the real value.
}
void preprocessing(cv::Mat & transformed_depth_frame,cv::Mat & color_frame,cv::Mat & HSV_frame)
{
	Mat imageROI_d, imageROI_c, imageROI_h, imageROI_m;
	imageROI_d = transformed_depth_frame(Range(up, down), Range(left, right));
	imageROI_c = color_frame(Range(up, down), Range(left,right));
	imageROI_h = HSV_frame(Range(up,down), Range(left,right));//这里在修改imageROI_h的同时也会修改HSV

	inRange(imageROI_d, dmin * 100, dmax * 100, maskd);

	cvtColor(imageROI_c, imageROI_h, COLOR_RGB2HSV);
	//GaussianBlur(HSV_frame, HSV_frame, Size(5, 5), 0, 0);
	inRange(imageROI_h, Scalar(lowH, lowS, lowV), Scalar(highH, highS, highV), maskc);
}




void tracking_core_processing(cv::Mat & transformed_depth_frame,cv::Mat & color_frame,std::ofstream & outfile,int& lost)
{
	bool have_found = false;
	Point2f center_color; float radius_color;

	Mat element = getStructuringElement(MORPH_RECT, Size(3, 3));
	morphologyEx(maskc, maskc, MORPH_CLOSE, element);
	//dilate(maskc,maskc,element);

	imshow("maskc", maskc);

	vector<vector<Point>> contours_color;
	vector<Vec4i> hierarcy_color;

	findContours(maskc, contours_color, hierarcy_color, RETR_TREE, CHAIN_APPROX_NONE);
	for (int i = 0; i < contours_color.size(); i++)
	{
		//cout <<"ok!"<<endl;
		minEnclosingCircle(contours_color[i], center_color ,radius_color);

		bool roundness_flag = false;//roundness detection
		double  area_circle= CV_PI * radius_color * radius_color;
		double area_inner = contourArea(contours_color[i]);
		double roundness = (area_inner/area_circle)*1000;
		//cout<<roundness<<endl;

		bool linearity_flag = false;//linearity detection
		center_color.x += left;center_color.y += up;
		float correct_depth = stablize(center_color,radius_color,transformed_depth_frame);
		//cout<<"Max :   "<<correct_depth<<endl;
		double linearity = radius_color* correct_depth/100;
		//cout<<transformed_depth_frame.at<ushort>(center_color.y, center_color.x)<<"-------"<<linearity<<endl;
				
		if(linearity > linearity_L&&linearity<linearity_H)
		{
			linearity_flag = true;
			if (roundness > roundness_L && roundness < roundness_H )roundness_flag=true;

		}
		// else if(linearity==0)
		// {
		// 	linearity_flag=true;
		// 	if (roundness > roundness_L && roundness < roundness_H )roundness_flag=true;			
		// }

		if(roundness_flag&& linearity_flag)
		{
		prediction = KF.predict();
		precenter.x=prediction.at<float>(0);
		precenter.y=prediction.at<float>(1);
		//cout<<"pre:  "<<prediction<<endl;

		measurement.at<float>(0) = (float)center_color.x;//update the measurement 
		measurement.at<float>(1) = (float)center_color.y;
		measurement.at<float>(2) = (float)transformed_depth_frame.at<ushort>(center_color.y,center_color.x);

		KF.correct(measurement);
		//cout<<"Gain :   "<<KF.gain<<endl;

		have_found = true;
		lost = 0;
		//cout<<"Radius :radius_color:  "<<radius_color<<endl;
		circle(color_frame, center_color, radius_color, Scalar(0, 0, 255), 2);
		circle(color_frame, precenter, radius_color, Scalar(0, 255, 0), 2);
		//send_data(prediction.at<float>(0)-color_frame.cols/2,prediction.at<float>(2));

		outfile << (int)transformed_depth_frame.at<ushort>(center_color.y, center_color.x) << "," 
		<<roundness << "," << linearity << "," << (roundness_flag && linearity_flag) << endl;
		}
		else					
		outfile << (int)transformed_depth_frame.at<ushort>(center_color.y, center_color.x) << "," 
		<< roundness << "," << linearity << "," << (roundness_flag && linearity_flag) << endl;
	}

	if(!have_found)
	{
		lost+=1;


		prediction = KF.predict();
		precenter.x=prediction.at<float>(0);
		precenter.y=prediction.at<float>(1);
		// cout<<"_______"<<endl;
		// cout<<precenter<<endl;
		// cout<<center_color<<endl;
		// cout<<"_______-"<<endl;


		//update the measurement 
		measurement.at<float>(0) = (float)prediction.at<float>(0);
		measurement.at<float>(1) = (float)prediction.at<float>(1);
		measurement.at<float>(2) = (float)prediction.at<float>(2);

		
		KF.correct(measurement);
		
		have_found = true;
		//circle(color_frame, center_color, radius_color, Scalar(0, 0, 255), 2);//the two cicles reprsent the predicted position
		circle(color_frame, precenter, radius_color, Scalar(0, 255, 0), 2);
		send_data(prediction.at<float>(0)-color_frame.cols/2,prediction.at<float>(2));
		// cout<<"!"<<endl;
		// send_data(2222,0);
	}



}


void detect_core_processing(Mat & transformed_depth_frame,Mat & color_frame,ofstream & outfile,int& lost)
{
	bool have_found = false;

	Mat element = getStructuringElement(MORPH_RECT, Size(3, 3));
	morphologyEx(maskc, maskc, MORPH_CLOSE, element);
	//dilate(maskc,maskc,element);

	imshow("maskc", maskc);

	vector<vector<Point>> contours_color;
	vector<Vec4i> hierarcy_color;

	findContours(maskc, contours_color, hierarcy_color, RETR_TREE, CHAIN_APPROX_NONE);
	for (int i = 0; i < contours_color.size(); i++)
	{
		//cout <<"ok!"<<endl;
		Point2f center_color; float radius_color;
		minEnclosingCircle(contours_color[i], center_color ,radius_color);

		bool roundness_flag = false;//roundness detection
		double  area_circle= CV_PI * radius_color * radius_color;
		double area_inner = contourArea(contours_color[i]);
		double roundness = (area_inner/area_circle)*1000;
		//cout<<roundness<<endl;
		if (roundness > roundness_L && roundness < roundness_H )roundness_flag=true;

		bool linearity_flag = false;//linearity detection
		center_color.x += left;center_color.y += up;
		float correct_depth = stablize(center_color,radius_color,transformed_depth_frame);
		//cout<<"Max :   "<<correct_depth<<endl;
		double linearity = radius_color* correct_depth/100;		
		//cout<<transformed_depth_frame.at<ushort>(center_color.y, center_color.x)<<"-------"<<linearity<<endl;
		
		if(linearity > linearity_L&&linearity<linearity_H)
		{
			linearity_flag = true;
			if (roundness > roundness_L && roundness < roundness_H )roundness_flag=true;

		}
		// else if(linearity==0)
		// {
		// 	linearity_flag=true;
		// 	if (roundness > roundness_L && roundness < roundness_H )roundness_flag=true;			
		// }					

		if(roundness_flag&& linearity_flag)
		{	
			measurement.at<float>(0) = (float)center_color.x;//initialize the measurment
			measurement.at<float>(1) = (float)center_color.y;
			measurement.at<float>(2) = (float)transformed_depth_frame.at<ushort>(center_color.y,center_color.x);

			have_found = true;lost = 0;
			circle(color_frame, center_color, radius_color, Scalar(0, 0, 255), 2);
			//send_data(center_color.x-color_frame.cols/2,(float)transformed_depth_frame.at<ushort>(center_color.y,center_color.x));
			// outfile << (int)transformed_depth_frame.at<ushort>(center_color.y, center_color.x) << " " 
			// <<roundness << " " << linearity << " " << (roundness_flag && linearity_flag) << endl;
		}
		else
		{
			outfile << (int)transformed_depth_frame.at<ushort>(center_color.y, center_color.x) << " " 
			<< roundness << " " << linearity << " " << (roundness_flag && linearity_flag) << endl;						
		}					
	}

	if(!have_found)
	{
		cout<<"!"<<endl;
		send_data(2222,0);
		lost = 5;
	}

}
float stablize(Point center,float radius,cv::Mat & transformed_depth_frame)
{
	int delta = (int)(radius - 2);
	float depth[9] = {0};
	int k = 0;
	float max = 0;
	for(int i=-1;i<2;i++)
	{
		for(int j=-1;k<8&&j<2;j++,k++)
		{
			//cout<<depth[k]<<endl;
			depth[k]=(float)transformed_depth_frame.at<ushort>((int)(center.y+i*delta),(int)(center.x+j*delta));
		}
	}
	for(int k=0;k<8;k++)
	{
		if(depth[k]<depth[k+1])max = depth[k+1];
		else max=depth[k];
	}
	//cout<<"MAx: "<<max<<endl;
	return max;
}
		// cout<<"______"<<endl;
		// cout<<"u(k)"<<control_vetor<<endl;
		// cout<<"A(k) :   "<<KF.transitionMatrix<<endl;
		// cout<<"B(k) :   "<<KF.controlMatrix<<endl;		
		// cout<<"P'(k) :   "<<KF.errorCovPre<<endl;
		//cout<<"pre:  "<<prediction<<endl;
		// cout<<"color:  "<<center_color<<endl;
		// cout<<"Q(k):    "<<KF.processNoiseCov<<endl;
		// cout<<"R(k):   "<<KF.measurementNoiseCov<<endl;
		// cout<<"_______-"<<endl;

		//cout<<delta_t<<endl;
		//cout<<"Post :   "<<KF.statePost<<endl;
		//cout<<"prediction:  "<<prediction<<endl;
		// cout<<"V_y:"<<vy<<endl;
		//cout<<"vxyd:  "<<vx<<"######"<<vy<<"#####"<<vd<<endl;
		//cout<<"Mea:  "<<measurement.at<float>(0)<<"######"<<measurement.at<float>(1)<<"#####"<<measurement.at<float>(2)<<endl;

		//cout<<"Post :   "<<KF.statePost<<endl;

		// cout<<"P'(k) :   "<<KF.errorCovPre<<endl;
		// cout<<"H(k):   "<<KF.measurementMatrix<<endl;
		// cout<<"Gain :   "<<KF.gain<<endl;
		// cout<<"POST:  "<<KF.statePost<<endl;
		// cout<<"P(k):  "<<KF.errorCovPost<<endl;
		
