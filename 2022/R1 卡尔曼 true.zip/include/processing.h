#ifndef _Processing_H
#define _Processing_H
#pragma onces

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <opencv2/video/tracking.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <cstdlib>
#include <omp.h>
#include <fstream>
#include <cmath>
#include "serial_port.h"
#include "visualization.h"
#define FramePerSecond 15
#define E5 100000
#define E4 10000
#define E3 1000

void trackbars();
void initialize();// initialize Kalman filter
void preprocessing(cv::Mat & transformed_depth_frame,cv::Mat & color_frame,cv::Mat & HSV_frame);
void detect_core_processing(cv::Mat & transformed_depth_frame,cv::Mat & color_frame,std::ofstream & outfile,int&lost);
void tracking_core_processing(cv::Mat & transformed_depth_frame,cv::Mat & color_frame,std::ofstream & outfile,int&lost);
#endif