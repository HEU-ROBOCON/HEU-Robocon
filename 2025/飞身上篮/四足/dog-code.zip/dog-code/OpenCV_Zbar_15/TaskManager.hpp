#pragma once
#include "RingDetector.hpp"
#include "SerialPort.hpp"
#include <array>
#include <memory>
#include <opencv2/opencv.hpp>
#include <string>
#include <zbar.h>

class TaskManager {
  public:
    TaskManager();
    ~TaskManager();
    void run();

  private:
    // 任务数组：前6位为任务码，第7位为当前检测到的颜色,8wei x, 9wei y
    std::array<int, 9> taskArray;
    bool qrCodeDetected = false;

    // 摄像头
    cv::VideoCapture cap1; // 二维码摄像头
    cv::VideoCapture cap2; // 颜色检测摄像头

    cv::VideoCapture &getActiveCamera() { return cap2; } // 用于共享摄像头

    // ZBar扫描器
    std::unique_ptr<zbar::ImageScanner> scanner;

    // 颜色检测相关
    cv::Point2f imageCenter;
    cv::Rect centerROI;

    struct ColorRange {
        cv::Scalar lower;
        cv::Scalar upper;
        std::string name;
        cv::Scalar color;
    };

    // 物块跟踪相关
    float lastDistance = 0;
    int stableCount = 0;
    const float MOVEMENT_THRESHOLD = 1.0f; // 距离变化阈值
    const int STABLE_FRAMES = 5;           // 需要保持稳定的帧数


    std::vector<ColorRange> colorRanges;

    // std::unique_ptr<SerialPort> serial;
    std::unique_ptr<RingDetector> ringDetector;
    bool detectingRing = false;
    bool bi  = false;

    // 初始化函数
    void initCameras();
    void initScanner();
    void initColorRanges();

    // 处理函数
    void processQRCode();
    void processColor();
    void processColor_bi();

    // 辅助函数
    void parseQRCode(std::string const &qrData);
    SerialPort serial;

};



