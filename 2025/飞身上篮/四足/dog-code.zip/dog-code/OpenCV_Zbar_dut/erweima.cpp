#include <iostream>
#include <opencv2/opencv.hpp>
#include <zbar.h>

using namespace cv;
using namespace std;
using namespace zbar;

int main() {
  VideoCapture cap(2);
  if (!cap.isOpened()) {
    cerr << "无法打开摄像头" << endl;
    return -1;
  }

  // 创建 ZBar 扫描器
  ImageScanner scanner;
  scanner.set_config(ZBAR_NONE, ZBAR_CFG_ENABLE, 1);

  while (true) {
    Mat frame;
    cap >> frame;
    if (frame.empty()) {
      break;
    }

    // 转换为灰度图
    Mat gray;
    cvtColor(frame, gray, COLOR_BGR2GRAY);

    // 创建 ZBar 图像
    Image image(gray.cols, gray.rows, "Y800", gray.data, gray.cols * gray.rows);

    // 扫描二维码
    int n = scanner.scan(image);
    for (Image::SymbolIterator symbol = image.symbol_begin();
         symbol != image.symbol_end(); ++symbol) {
      cout << "解码内容: " << symbol->get_data() << endl;

      // 在图像中绘制检测到的二维码位置
      vector<Point> points;
      for (int i = 0; i < symbol->get_location_size(); i++) {
        points.push_back(
            Point(symbol->get_location_x(i), symbol->get_location_y(i)));
      }
      polylines(frame, points, true, Scalar(0, 255, 0), 2);
    }

    // 显示结果
    imshow("摄像头", frame);

    // 按下 'q' 键退出
    if (waitKey(30) == 'q')
      break;
  }

  cap.release();
  destroyAllWindows();
  return 0;
}
