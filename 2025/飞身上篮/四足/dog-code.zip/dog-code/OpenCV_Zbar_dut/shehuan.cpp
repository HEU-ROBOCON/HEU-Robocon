//
// Created by zgh on 2025/2/20.
//
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <vector>

using namespace cv;
using namespace std;

class RingDetector {
private:
    Mat frame;
    Point2f imageCenter;
    vector<Point2f> ringCenters;

public:
    RingDetector() {
        // 打开摄像头
        VideoCapture cap(2);
        if (!cap.isOpened()) {
            cout << "无法打开摄像头" << endl;
            return;
        }

        // 获取图像尺寸并计算中心点
        cap.read(frame);
        imageCenter = Point2f(frame.cols / 2.0f, frame.rows / 2.0f);

        namedWindow("Parameters");
        createTrackbars();

        while (true) {
            cap.read(frame);
            if (frame.empty()) break;

            // 处理每一帧
            processFrame();

            // 显示结果
            showResults();

            // 按'q'退出
            if (waitKey(1) == 'q') break;
        }

        cap.release();
        destroyAllWindows();
    }

private:
    // 滑动条参数
    struct Parameters {
        static int cannyThreshold1;
        static int cannyThreshold2;
        static int minRadius;
        static int maxRadius;
        static int minDist;
    } params;

    void createTrackbars() {
        createTrackbar("Canny Threshold1", "Parameters", &params.cannyThreshold1, 255);
        createTrackbar("Canny Threshold2", "Parameters", &params.cannyThreshold2, 255);
        createTrackbar("Min Radius", "Parameters", &params.minRadius, 100);
        createTrackbar("Max Radius", "Parameters", &params.maxRadius, 200);
        createTrackbar("Min Distance", "Parameters", &params.minDist, 200);
    }

    void processFrame() {
        // 预处理
        Mat gray, blurred, edges;
        cvtColor(frame, gray, COLOR_BGR2GRAY);
        GaussianBlur(gray, blurred, Size(5, 5), 1.5);

        // Canny边缘检测
        Canny(blurred, edges, params.cannyThreshold1, params.cannyThreshold2);

        // 霍夫圆变换检测圆
        vector<Vec3f> circles;
        HoughCircles(blurred, circles, HOUGH_GRADIENT, 1,
                     params.minDist,  // 最小圆心距离
                     params.cannyThreshold2, // Canny高阈值
                     30,             // 累加器阈值
                     params.minRadius,      // 最小半径
                     params.maxRadius       // 最大半径
        );

        // 对检测到的圆进行分组（找到同心圆）
        vector<vector<Vec3f>> concentricCircles;
        for (const auto& circle : circles) {
            Point2f center(circle[0], circle[1]);
            float radius = circle[2];

            bool found = false;
            // 检查是否属于现有的同心圆组
            for (auto& group : concentricCircles) {
                Point2f groupCenter(group[0][0], group[0][1]);
                float distance = norm(center - groupCenter);
                if (distance < 20) {  // 允许的圆心偏差
                    group.push_back(circle);
                    found = true;
                    break;
                }
            }

            // 如果不属于任何组，创建新组
            if (!found) {
                concentricCircles.push_back({circle});
            }
        }

        // 只保留包含多个圆的组（同心圆环）
        ringCenters.clear();
        for (const auto& group : concentricCircles) {
            if (group.size() >= 2) {  // 至少需要2个圆才构成圆环
                Point2f center(group[0][0], group[0][1]);
                ringCenters.push_back(center);

                // 在原图上标记
                for (const auto& circle : group) {
                    Point2f circleCenter(circle[0], circle[1]);
                    float radius = circle[2];
                    cv::circle(frame, circleCenter, radius, Scalar(0, 255, 0), 2);
                }

                // 标记圆心
                circle(frame, center, 6, Scalar(0, 0, 255), -1);

                // 计算并显示相对坐标
                Point2f relativePos = center - imageCenter;
                putText(frame,
                        "(" + to_string(int(relativePos.x)) + "," + to_string(int(relativePos.y)) + ")",
                        Point(center.x + 10, center.y),
                        FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 0), 1);

                cout << "圆环中心相对坐标: ("
                     << relativePos.x << ", " << relativePos.y << ")" << endl;
            }
        }

        // 显示边缘检测结果
        imshow("Edges", edges);
    }

    void showResults() {
        // 绘制图像中心十字线
        line(frame,
             Point(imageCenter.x - 10, imageCenter.y),
             Point(imageCenter.x + 10, imageCenter.y),
             Scalar(0, 0, 255), 2);
        line(frame,
             Point(imageCenter.x, imageCenter.y - 10),
             Point(imageCenter.x, imageCenter.y + 10),
             Scalar(0, 0, 255), 2);

        // 显示结果
        imshow("Ring Detection", frame);
    }
};

// 初始化静态成员变量
int RingDetector::Parameters::cannyThreshold1 = 50;
int RingDetector::Parameters::cannyThreshold2 = 150;
int RingDetector::Parameters::minRadius = 20;
int RingDetector::Parameters::maxRadius = 100;
int RingDetector::Parameters::minDist = 50;

int main() {
    RingDetector detector;
    return 0;
}