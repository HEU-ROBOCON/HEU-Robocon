//
// Created by zgh on 2025/2/20.
//
#include <opencv2/opencv.hpp>
#include <iostream>
#include <opencv2/videoio.hpp>
#include <vector>

using namespace cv;
using namespace std;

// class CircleDetector {
// private:
//     Mat frame;
//     Point2f imageCenter;
//
//     // HSV颜色范围
//     struct ColorRange {
//         Scalar lower;
//         Scalar upper;
//         string name;
//         Scalar color;
//     };
//
//     vector<ColorRange> colorRanges = {
//             {{0, 100, 100}, {10, 255, 255}, "red", Scalar(0,0,255)},
//             {{170, 100, 100}, {180, 255, 255}, "red", Scalar(0,0,255)}, // 红色分两段
//             {{35, 100, 100}, {85, 255, 255}, "green", Scalar(0,255,0)},
//             // {{15, 100, 100}, {95, 255, 255}, "green", Scalar(0,255,0)},
//             {{100, 100, 100}, {130, 255, 255}, "blue", Scalar(255,0,0)}
//     };
//
// public:
//     CircleDetector() {
//         VideoCapture cap(2,cv::CAP_V4L2);
//         if (!cap.isOpened()) {
//             cout << "无法打开摄像头" << endl;
//             return;
//         }
//
//         cap.read(frame);
//         imageCenter = Point2f(frame.cols/2.0f, frame.rows/2.0f);
//
//         namedWindow("Parameters");
//         createTrackbars();
//
//         while (true) {
//             cap.read(frame);
//             if (frame.empty()) break;
//
//             processFrame();
//
//             if (waitKey(1) == 'q') break;
//         }
//
//         cap.release();
//         destroyAllWindows();
//     }
//
// private:
//     struct Parameters {
//         static int minRadius;
//         static int maxRadius;
//         static int blurSize;
//         static int minArea;
//     } params;
//
//     void createTrackbars() {
//         createTrackbar("Min Radius", "Parameters", &params.minRadius, 100);
//         createTrackbar("Max Radius", "Parameters", &params.maxRadius, 200);
//         createTrackbar("Blur Size", "Parameters", &params.blurSize, 20);
//         createTrackbar("Min Area", "Parameters", &params.minArea, 5000);
//     }
//
//     void processFrame() {
//         // 高斯模糊减少噪声
//         Mat blurred;
//         int blurSize = params.blurSize * 2 + 1;
//         GaussianBlur(frame, blurred, Size(blurSize, blurSize), 0);
//
//         // 转换到HSV颜色空间
//         Mat hsv;
//         cvtColor(blurred, hsv, COLOR_BGR2HSV);
//
//         // 处理每种颜色
//         for (const auto& range : colorRanges) {
//             // 颜色分割
//             Mat mask;
//             inRange(hsv, range.lower, range.upper, mask);
//
//             // 形态学操作
//             Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(5, 5));
//             morphologyEx(mask, mask, MORPH_OPEN, kernel);
//             morphologyEx(mask, mask, MORPH_CLOSE, kernel);
//
//             // 查找轮廓
//             vector<vector<Point>> contours;
//             findContours(mask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
//
//             // 分析每个轮廓
//             for (const auto& contour : contours) {
//                 double area = contourArea(contour);
//                 if (area < params.minArea) continue;
//
//                 // 计算圆形度
//                 double perimeter = arcLength(contour, true);
//                 double circularity = 4 * CV_PI * area / (perimeter * perimeter);
//                 if (circularity < 0.8) continue; // 圆形度阈值
//
//                 // 找到最小外接圆
//                 Point2f center;
//                 float radius;
//                 minEnclosingCircle(contour, center, radius);
//
//                 // 验证半径是否在合理范围内
//                 if (radius < params.minRadius || radius > params.maxRadius) continue;
//
//                 // 计算相对坐标
//                 Point2f relativePos = center - imageCenter;
//
//                 // 在原图上标记
//                 circle(frame, center, radius, range.color, 2);
//                 circle(frame, center, 3, range.color, -1);
//
//                 // 显示颜色和坐标
//                 string text = range.name + " (" +
//                               to_string(int(relativePos.x)) + "," +
//                               to_string(int(relativePos.y)) + ")";
//                 putText(frame, text,
//                         Point(center.x + 10, center.y),
//                         FONT_HERSHEY_SIMPLEX, 0.5, range.color, 2);
//
//                 cout << range.name << " 圆心相对坐标: ("
//                      << relativePos.x << ", " << relativePos.y << ")" << endl;
//             }
//
//             // 显示颜色掩码
//             string windowName = "Mask " + range.name;
//             imshow(windowName, mask);
//         }
//
//         // 绘制图像中心十字线
//         line(frame,
//              Point(imageCenter.x - 10, imageCenter.y),
//              Point(imageCenter.x + 10, imageCenter.y),
//              Scalar(0, 0, 255), 2);
//         line(frame,
//              Point(imageCenter.x, imageCenter.y - 10),
//              Point(imageCenter.x, imageCenter.y + 10),
//              Scalar(0, 0, 255), 2);
//
//         // 显示结果
//         imshow("Circle Detection", frame);
//     }
// };
//
// // 初始化静态成员变量
// int CircleDetector::Parameters::minRadius = 20;
// int CircleDetector::Parameters::maxRadius = 100;
// int CircleDetector::Parameters::blurSize = 3;
// int CircleDetector::Parameters::minArea = 1000;
//
// int main() {
//     CircleDetector detector;
//     return 0;
// }

class CircleDetector {
private:
    Mat frame;
    Point2f imageCenter;
    Rect centerROI;  // 中心矩形区域
    bool redFlag = false;
    bool greenFlag = false;
    bool blueFlag = false;

    struct ColorRange {
        Scalar lower;
        Scalar upper;
        string name;
        Scalar color;
    };

    // vector<ColorRange> colorRanges = {
    //         {{0, 100, 100}, {10, 255, 255}, "red", Scalar(0,0,255)},
    //         {{170, 100, 100}, {180, 255, 255}, "red", Scalar(0,0,255)},
    //         {{35, 100, 100}, {85, 255, 255}, "green", Scalar(0,255,0)},
    //         {{100, 100, 100}, {130, 255, 255}, "blue", Scalar(255,0,0)}
    // };

    vector<ColorRange> colorRanges = {
        // 红色范围扩大，降低饱和度和亮度要求
        {{0, 70, 50}, {10, 255, 255}, "red", Scalar(0,0,255)},
        {{170, 70, 50}, {180, 255, 255}, "red", Scalar(0,0,255)},
        // 绿色范围扩大，降低饱和度和亮度要求
        {{35, 70, 50}, {85, 255, 255}, "green", Scalar(0,255,0)},
        // 蓝色范围扩大，降低饱和度和亮度要求
        {{100, 70, 50}, {130, 255, 255}, "blue", Scalar(255,0,0)}
    };

public:
    CircleDetector() {
        VideoCapture cap(2, cv::CAP_V4L2);
        if (!cap.isOpened()) {
            cout << "无法打开摄像头" << endl;
            return;
        }

        cap.read(frame);
        imageCenter = Point2f(frame.cols/2.0f, frame.rows/2.0f);
        
        // 计算中心矩形区域
        int roiSize = min(frame.cols, frame.rows) / 4;
        centerROI = Rect(
            imageCenter.x - roiSize/2,
            imageCenter.y - roiSize/2,
            roiSize,
            roiSize
        );

        while (true) {
            cap.read(frame);
            if (frame.empty()) break;

            processFrame();

            if (waitKey(1) == 'q') break;
        }

        cap.release();
        destroyAllWindows();
    }

private:
    void processFrame() {
        // 自适应直方图均衡化
        Mat lab;
        cvtColor(frame, lab, COLOR_BGR2Lab);
        vector<Mat> lab_planes(3);
        split(lab, lab_planes);
        Ptr<CLAHE> clahe = createCLAHE(2.0, Size(8,8));
        Mat dst;
        clahe->apply(lab_planes[0], dst);
        dst.copyTo(lab_planes[0]);
        merge(lab_planes, lab);
        cvtColor(lab, frame, COLOR_Lab2BGR);

        // 高斯模糊减少噪声
        Mat blurred;
        GaussianBlur(frame, blurred, Size(5, 5), 0);

        // 转换到HSV颜色空间
        Mat hsv;
        cvtColor(blurred, hsv, COLOR_BGR2HSV);

        // 重置标志位
        redFlag = false;
        greenFlag = false;
        blueFlag = false;

        // 处理每种颜色
        for (const auto& range : colorRanges) {
            // 颜色分割
            Mat mask;
            inRange(hsv, range.lower, range.upper, mask);

            // 形态学操作
            Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(5, 5));
            morphologyEx(mask, mask, MORPH_OPEN, kernel);
            morphologyEx(mask, mask, MORPH_CLOSE, kernel);

            // 添加中值滤波去除噪点
            medianBlur(mask, mask, 5);

            // 计算ROI区域内的颜色占比
            Mat roiMask = mask(centerROI);
            int colorPixels = countNonZero(roiMask);
            float colorRatio = (float)colorPixels / (centerROI.width * centerROI.height);

            // 更新标志位并在图像上标记
            if (colorRatio > 0.2) {  // 20%阈值
                if (range.name == "red") {
                    redFlag = true;
                    putText(frame, "RED", 
                        Point(centerROI.x, centerROI.y - 10),
                        FONT_HERSHEY_SIMPLEX, 0.8, Scalar(0,0,255), 2);
                }
                else if (range.name == "green") {
                    greenFlag = true;
                    putText(frame, "GREEN", 
                        Point(centerROI.x, centerROI.y + centerROI.height + 25),
                        FONT_HERSHEY_SIMPLEX, 0.8, Scalar(0,255,0), 2);
                }
                else if (range.name == "blue") {
                    blueFlag = true;
                    putText(frame, "BLUE", 
                        Point(centerROI.x + centerROI.width + 10, centerROI.y + centerROI.height/2),
                        FONT_HERSHEY_SIMPLEX, 0.8, Scalar(255,0,0), 2);
                }
            }

            // 显示颜色掩码
            string windowName = "Mask " + range.name;
            imshow(windowName, mask);
        }

        // 绘制中心矩形区域
        rectangle(frame, centerROI, Scalar(0, 255, 255), 2);  // 黄色矩形框

        // 显示标志位状态
        string flags = "Flags - Red: " + to_string(redFlag) + 
                      " Green: " + to_string(greenFlag) + 
                      " Blue: " + to_string(blueFlag);
        putText(frame, flags, Point(10, 30), 
                FONT_HERSHEY_SIMPLEX, 0.7, Scalar(0, 255, 255), 2);

        // 打印标志位状态
        cout << "\rRed: " << redFlag << 
                " Green: " << greenFlag << 
                " Blue: " << blueFlag << endl;

        // 显示结果
        imshow("Color Detection", frame);
    }
};

int main() {
    CircleDetector detector;
    return 0;
}
