#include "TaskManager.hpp"
#include <iostream>
#include <ostream>

TaskManager::TaskManager() {
    taskArray.fill(0); // 初始化任务数组为0
    initCameras();
    initScanner();
    initColorRanges();
}

TaskManager::~TaskManager() {
    cap1.release();
    cap2.release();
    cv::destroyAllWindows();
}

void TaskManager::initCameras() {
    cap1.open(0, cv::CAP_V4L2); // 二维码摄像头
    cap2.open(2, cv::CAP_V4L2); // 颜色检测摄像头

    if (!cap1.isOpened() || !cap2.isOpened()) {
       throw std::runtime_error("无法打开摄像头");
    }
    // if (!cap1.isOpened()) {
    //     throw std::runtime_error("无法打开摄像头");
    // }

    // 初始化颜色检测相关参数
    cv::Mat frame;
    cap2.read(frame);
    imageCenter = cv::Point2f(frame.cols / 2.0f, frame.rows / 2.0f);
    int roiSize = std::min(frame.cols, frame.rows) / 4;
    centerROI = cv::Rect(imageCenter.x - roiSize / 2,
                         imageCenter.y - roiSize / 2, roiSize, roiSize);
}

void TaskManager::initScanner() {
    scanner = std::make_unique<zbar::ImageScanner>();
    scanner->set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 1);
}

void TaskManager::initColorRanges() {
    colorRanges = {
        {{0, 70, 50}, {20, 255, 255}, "red", cv::Scalar(0, 0, 255)},
        {{160, 70, 50}, {180, 255, 255}, "red", cv::Scalar(0, 0, 255)},
        {{35, 70, 50}, {85, 255, 255}, "green", cv::Scalar(0, 255, 0)},
        {{100, 70, 50}, {130, 255, 255}, "blue", cv::Scalar(255, 0, 0)}};
}

// void testSendArray() {
//     std::cout << "测试发送任务数组..." << std::endl;
//
//     try {
//         SerialPort serial("/dev/ttyUSB0",
//                           B115200); // 使用USB转串口，波特率115200
//         if (!serial.isOpen()) {
//             std::cout << "串口打开失败！" << std::endl;
//             return;
//         }
//
//         // 测试数据
//         std::array<int, 7> testArray1 = {1, 2, 3, 4, 5, 6, 1};
//         std::array<int, 7> testArray2 = {6, 5, 4, 3, 2, 1, 1};
//
//         bool send = false;
//         int i = 0;
//         while (1) {
//             if (i % 2) {
//                 send = serial.sendArray(testArray1);
//             } else {
//                 send = serial.sendArray(testArray2);
//             }
//             if (send) {
//                 std::cout << "成功发送数组: ";
//                 if (i % 2) {
//                     for (int val : testArray1) {
//                         std::cout << val << " ";
//                     }
//                 } else {
//                     for (int val : testArray2) {
//                         std::cout << val << " ";
//                     }
//                 }
//
//                 std::cout << std::endl;
//             } else {
//                 std::cout << "发送失败！" << std::endl;
//             }
//
//             // 等待接收数据
//             int received = serial.receiveData();
//             if (received != -1) {
//                 std::cout << "收到数据: " << received << std::endl;
//             }
//
//             i++;
//             // std::this_thread::sleep_for(std::chrono::milliseconds(500));
//         }
//
//     } catch (std::exception const &e) {
//         std::cout << "错误: " << e.what() << std::endl;
//     }
// }

/*
void TaskManager::run() {
    //    while (1){
    //        testSendArray();
    //    }
    //     serial = std::make_unique<SerialPort>();
    //     if (!serial->isOpen()) {
    //         throw std::runtime_error("无法打开串口");
    //     }
    //
    //

    SerialPort serial("/dev/ttyUSB0",
                      B115200); // 使用USB转串口，波特率115200
    if (!serial.isOpen()) {
        std::cout << "串口打开失败！" << std::endl;
        return;
    }
    while (true) {

        if (!detectingRing) {
            // 处理二维码和颜色检测
            if (!qrCodeDetected) {
                processQRCode();
            }
            if(bi){
                processColor_bi();
            }else{
            processColor();
            }


            // 发送任务数组到STM32
            serial.sendArray(taskArray);

            int received = serial.receiveData();
            // 检查是否收到切换信号
            if (received == 1) {
                detectingRing = true;
                ringDetector =
                    std::make_unique<RingDetector>(getActiveCamera());
            }
            if (received == 3) {
                detectingRing = true;
            }
        } else {
            // 色环检测和定位
            auto coordinates = ringDetector->processFrame();
            if (coordinates.has_value()) {
                serial.sendCoordinates(coordinates->x, coordinates->y);
                int received = serial.receiveData();
                if (received == 2) {
                    detectingRing = false;
                }
                if (received == 4) {
                    detectingRing = false;
                    bi = true;
                }

                std::cout << "( " << coordinates->x << " ," << coordinates->y
                          << std::endl;
            }
        }

        if (cv::waitKey(1) == 'q') {
            break;
        }
    }
}
*/

// bool reopenSerial() {
//     try {
//         SerialPort ser("/dev/ttyUSB0",
//                       B115200);
//         if (ser.isOpen()) {
//             return true;
//         } else {
//             return false;
//         }
//     } catch (serial::SerialException &e) {
//         return false;
//     } catch (serial::IOException &e) {
//         return false;
//     }
// }



void TaskManager::run() {


    while (true) {

        if (!detectingRing) {
            // 处理二维码和颜色检测
            if (!qrCodeDetected) {
                processQRCode();
            }
            if(bi){
                processQRCode128();
                int received = serial.receiveData();
                if (received == 3)
                {
                    bi = false;
                }
                

            }else{
                processColor();
                int received = serial.receiveData();
                if (received == 4)
                {
                    auto coordinates = ringDetector->processFrame();

                    if (coordinates.has_value()) {
                        serial.sendCoordinates(coordinates->x, coordinates->y);
                    }
                }
            }


            // 发送任务数组到STM32
            serial.sendArray(taskArray);

            int received = serial.receiveData();
            // 检查是否收到切换信号
            if (received == 1) {
                detectingRing = true;
                ringDetector =
                    std::make_unique<RingDetector>(getActiveCamera());
            }

        } else {
            // 色环检测和定位
            auto coordinates = ringDetector->processFrame();
            if (coordinates.has_value()) {
                serial.sendCoordinates(coordinates->x, coordinates->y);
                int received = serial.receiveData();
                if (received == 2) {
                    detectingRing = false;
                    bi = true;

                }
                if (received == 4) {
                    detectingRing = false;
                    bi = true;
                }

                std::cout << "( " << coordinates->x << " ," << coordinates->y
                          << std::endl;
            }
        }

        if (cv::waitKey(1) == 'q') {
            break;
        }
    }
}

void TaskManager::run() {

// sdfsdfsdf
    while (true) {

        if (!detectingRing) {
            // 处理二维码和颜色检测
            if (!qrCodeDetected) {
                processQRCode();
            }
            if(bi){
                processQRCode128();
            }else{
            processColor();
            }


            // 发送任务数组到STM32
            serial.sendArray(taskArray);

            int received = serial.receiveData();
            // 检查是否收到切换信号
            if (received == 1) {
                detectingRing = true;
                ringDetector =
                    std::make_unique<RingDetector>(getActiveCamera());
            }
            if (received == 3) {
                detectingRing = true;
            }
        } else {
            // 色环检测和定位
            auto coordinates = ringDetector->processFrame();
            if (coordinates.has_value()) {
                serial.sendCoordinates(coordinates->x, coordinates->y);
                int received = serial.receiveData();
                if (received == 2) {
                    detectingRing = false;
                }
                if (received == 4) {
                    detectingRing = false;
                    bi = true;
                }

                std::cout << "( " << coordinates->x << " ," << coordinates->y
                          << std::endl;
            }
        }

        if (cv::waitKey(1) == 'q') {
            break;
        }
    }
}

//1234567

// void TaskManager::run() {

//     SerialPort serial("/dev/ttyUSB0",
//                       B115200); // 使用USB转串口，波特率115200
//     if (!serial.isOpen()) {
//         std::cout << "串口打开失败！" << std::endl;
//         return;
//     }
//     ringDetector =std::make_unique<RingDetector>(cap1);
//     while (true) {

            

//             auto coordinates = ringDetector->processFrame();
//             if (coordinates.has_value()) {
//                 serial.sendCoordinates(coordinates->x, coordinates->y);
//                 std::cout << "( " << coordinates->x << " ," << coordinates->y
//                           << std::endl;
//             }

//         if (cv::waitKey(1) == 'q') {
//             break;
//         }
//     }
// }


// void TaskManager::run() {

//     SerialPort serial("/dev/ttyUSB0",
//                       B115200); // 使用USB转串口，波特率115200
//     if (!serial.isOpen()) {
//         std::cout << "串口打开失败！" << std::endl;
//         return;
//     }else{
//         std::cout << "串口打开chenggong！" << std::endl;

//     }

//     while (true) {

//         processQRCode128();

//         if (cv::waitKey(1) == 'q') {
//             break;
//         }
//     }
// }


// void TaskManager::run() {
//     // ... existing code ...
//
//     SerialPort serial("/dev/ttyUSB0", B115200);
//     if (!serial.isOpen()) {
//         std::cout << "串口打开失败！" << std::endl;
//         return;
//     }
//
//     enum State {
//         QR_COLOR_DETECTION,
//         RING_DETECTION_1,
//         COLOR_DETECTION_2,
//         RING_DETECTION_2
//     };
//void TaskManager::run() {

//     SerialPort serial("/dev/ttyUSB0",
//                       B115200); // 使用USB转串口，波特率115200
//     if (!serial.isOpen()) {
//         std::cout << "串口打开失败！" << std::endl;
//         return;
//     }
//     ringDetector =std::make_unique<RingDetector>(cap1);
//     while (true) {

            

//             auto coordinates = ringDetector->processFrame();
//             if (coordinates.has_value()) {
//                 serial.sendCoordinates(coordinates->x, coordinates->y);
//                 std::cout << "( " << coordinates->x << " ," << coordinates->y
//                           << std::endl;
//             }

//         if (cv::waitKey(1) == 'q') {
//             break;
//         }
//     }
// }
//     State currentState = QR_COLOR_DETECTION;
//     int colorCode;
//     std::optional<cv::Point2f> coordinates;
//
//     while (true) {
//         switch (currentState) {
//         case QR_COLOR_DETECTION:
//             // if (!qrCodeDetected) {
//             //     processQRCode();
//             // }
//             //
//             processQRCode();
//             colorCode = processColor();
//             taskArray[6] = colorCode;
//             serial.sendArray(taskArray);
//
//             if (serial.receiveData() == 1) {
//                 currentState = RING_DETECTION_1;
//             }
//             break;
//         case RING_DETECTION_1: {
//             auto ringDetector =
//                 std::make_unique<RingDetector>(getActiveCamera());
//             coordinates = ringDetector->processFrame();
//             if (coordinates.has_value()) {
//                 serial.sendCoordinates(coordinates->x, coordinates->y);
//                 std::cout << "( " << coordinates->x << " ," <<
// coordinates->y
//                           << std::endl;
//             }
//
//             if (serial.receiveData() == 2) {
//                 currentState = COLOR_DETECTION_2;
//             }
//         } break;
//
//         case COLOR_DETECTION_2: {
//             colorCode = processColor();
//             taskArray[6] = colorCode;
//             serial.sendArray(taskArray);
//
//             if (serial.receiveData() == 3) {
//                 currentState = RING_DETECTION_2;
//                 // ringDetector =
//                 //     std::make_unique<RingDetector>(getActiveCamera());
//             }
//         } break;
//
//         case RING_DETECTION_2: {
//             coordinates = ringDetector->processFrame();
//             if (coordinates.has_value()) {
//                 serial.sendCoordinates(coordinates->x, coordinates->y);
//                 std::cout << "( " << coordinates->x << " ," <<
// coordinates->y
//                           << std::endl;
//             }
//         } break;
//         }
//
//         if (cv::waitKey(1) == 'q') {
//             break;
//         }
//     }
// }

// void TaskManager::run() {
//
//     ringDetector = std::make_unique<RingDetector>(getActiveCamera());
//
//     while (true) {
//         auto coordinates = ringDetector->processFrame();
//         if (coordinates.has_value()) {
//             std::cout << coordinates->x << " , " << coordinates->y <<
//             std::endl;
//         }
//
//         displayResults();
//         if (cv::waitKey(1) == 'q') {
//             break;
//         }
//     }
// }

// void TaskManager::run() {
//     while (true) {
//         auto start = std::chrono::steady_clock::now(); // 添加性能监控
//
//         int colorCode = processColor();
//         std::cout << "colorCode: " << colorCode << "\n";
//
//         auto end = std::chrono::steady_clock::now();
//         auto duration =
//             std::chrono::duration_cast<std::chrono::milliseconds>(end -
//             start)
//                 .count();
//         std::cout << "Processing time: " << duration << "ms\n";
//         if (cv::waitKey(1) == 'q') {
//             break;
//         }
//     }
// }

// void TaskManager::processQRCode() {
//     std::cout << "二维码来了" << std::endl;
//     cv::Mat frame;
//     cap1 >> frame;
//     if (frame.empty()) {
//         return;
//     }
//
//     cv::Mat gray;
//     cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
//
//     zbar::Image image(gray.cols, gray.rows, "Y800", gray.data,
//                       gray.cols * gray.rows);
//
//     if (scanner->scan(image) > 0) {
//         for (auto symbol = image.symbol_begin(); symbol !=
//         image.symbol_end();
//              ++symbol) {
//             std::string qrData = symbol->get_data();
//             std::cout << "----------" << std::endl;
//             parseQRCode(qrData);
//
//             qrCodeDetected = true;
//
//             // 在图像上显示二维码位置
//             std::vector<cv::Point> points;
//             for (int i = 0; i < symbol->get_location_size(); i++) {
//                 points.push_back(cv::Point(symbol->get_location_x(i),
//                                            symbol->get_location_y(i)));
//             }
//             cv::polylines(frame, points, true, cv::Scalar(0, 255, 0), 2);
//         }
//     }
//
//     cv::imshow("QR Code", frame);
// }

void TaskManager::processQRCode128() {
    // std::cout << "正在处理二维码..." << std::endl;

    // 确保窗口创建
    cv::namedWindow("Code128", cv::WINDOW_AUTOSIZE);

    cv::Mat frame;
    cap2 >> frame;
    if (frame.empty()) {
        std::cout << "无法获取摄像头图像" << std::endl;
        return;
    }

    // 显示原始图像尺寸
    // std::cout << "图像尺寸: " << frame.size() << std::endl;

    cv::Mat gray;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
    cv::imshow("code128", gray);
    // std::cout << "gray gray "  << std::endl;


    // 检查灰度图转换是否成功
    if (gray.empty()) {
        std::cout << "灰度图转换失败" << std::endl;
        return;
    }else{
        // std::cout << "灰度图转换cehngong" << std::endl;
    }

    // 创建zbar图像
    zbar::Image image(gray.cols, gray.rows, "Y800", gray.data,
                      gray.cols * gray.rows);
        // std::cout << "创建zbar成功" << std::endl;


    // 扫描二维码
    int result = scanner->scan(image);
    // std::cout << "扫描成功" << std::endl;

    std::cout << "code128扫描结果: " << result << std::endl;

    if (result > 0) {
        for (auto symbol = image.symbol_begin(); symbol != image.symbol_end();
             ++symbol) {
            std::string qrData = symbol->get_data();
            std::cout << "识别到128二维码数据: " << qrData << std::endl;

            // parseQRCode(qrData);
            // qrCodeDetected = true;

            // 在图像上显示二维码位置
            std::vector<cv::Point> points;
            std::vector<cv::Point> point_128;
            std::vector<int> pointx, pointy;
            cv::Point point_min, point_max;
            for (int i = 0; i < symbol->get_location_size(); i++) {
                points.push_back(cv::Point(symbol->get_location_x(i),
                                           symbol->get_location_y(i)));
            }

            for (int i = 0; i < symbol->get_location_size(); i++) {
                // points.push_back(cv::Point(symbol->get_location_x(i),
                //                            symbol->get_location_y(i)));
                pointx.push_back(symbol->get_location_x(i));
                pointy.push_back(symbol->get_location_y(i));
            }

            std::sort(pointx.begin(),pointx.end());
            std::sort(pointy.begin(),pointy.end());

            point_min.x = pointx.front();
            point_min.y = pointy.front();
            
            point_max.x = pointx.back();
            point_max.y = pointy.back();

            float dis = std::sqrt((point_max.x-point_min.x) * (point_max.x-point_min.x) + (point_max.x-point_min.x) * (point_max.y-point_min.y));
            float k = 60 / dis;

            int real_x = k * (point_min.x + point_max.x)/2;
            int real_y = k * (point_min.y + point_max.y)/2;

            std::cout<< real_x << " , "<< real_y<<std::endl;

            point_128.push_back(point_min);
            point_128.push_back(point_max);

            taskArray[6] = qrData[0] - '0';
            taskArray[7] = real_x;
            taskArray[8] = real_y;

            cv::polylines(frame, point_128, true, cv::Scalar(0, 255, 0), 2);

            // 绘制二维码边框
            // cv::polylines(frame, points, true, cv::Scalar(0, 255, 0), 2);

            // 显示二维码内容
            cv::putText(frame, qrData, points[0], cv::FONT_HERSHEY_SIMPLEX, 1.0,
                        cv::Scalar(0, 255, 0), 2);
        }
    }

    // 显示图像
    cv::imshow("128 Code", frame);
    cv::waitKey(1); // 给窗口更新一个短暂的延时
}

void TaskManager::parseQRCode128(std::string const &qrData) {
    if (qrData.length() == 7 && qrData[3] == '+') {
        for (int i = 0; i < 3; i++) {
            taskArray[i] = qrData[i] - '0';
            taskArray[i + 3] = qrData[i + 4] - '0';
        }
    }
}


void TaskManager::processQRCode() {
    //std::cout << "正在处理二维码..." << std::endl;

    // 确保窗口创建
    cv::namedWindow("QR Code", cv::WINDOW_AUTOSIZE);

    cv::Mat frame;
    cap1 >> frame;
    if (frame.empty()) {
        std::cout << "无法获取摄像头图像" << std::endl;
        return;
    }

    // 显示原始图像尺寸
    //std::cout << "图像尺寸: " << frame.size() << std::endl;

    cv::Mat gray;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);

    // 检查灰度图转换是否成功
    if (gray.empty()) {
        std::cout << "灰度图转换失败" << std::endl;
        return;
    }

    // 创建zbar图像
    zbar::Image image(gray.cols, gray.rows, "Y800", gray.data,
                      gray.cols * gray.rows);

    // 扫描二维码
    int result = scanner->scan(image);
    std::cout << "扫描结果: " << result << std::endl;

    if (result > 0) {
        for (auto symbol = image.symbol_begin(); symbol != image.symbol_end();
             ++symbol) {
            std::string qrData = symbol->get_data();
            std::cout << "识别到二维码数据: " << qrData << std::endl;

            parseQRCode(qrData);
            qrCodeDetected = true;

            // 在图像上显示二维码位置
            std::vector<cv::Point> points;
            for (int i = 0; i < symbol->get_location_size(); i++) {
                points.push_back(cv::Point(symbol->get_location_x(i),
                                           symbol->get_location_y(i)));
            }

            // 绘制二维码边框
            cv::polylines(frame, points, true, cv::Scalar(0, 255, 0), 2);

            // 显示二维码内容
            cv::putText(frame, qrData, points[0], cv::FONT_HERSHEY_SIMPLEX, 1.0,
                        cv::Scalar(0, 255, 0), 2);
        }
    }

    // 显示图像
    cv::imshow("QR Code", frame);
    cv::waitKey(1); // 给窗口更新一个短暂的延时
}

void TaskManager::parseQRCode(std::string const &qrData) {
    if (qrData.length() == 7 && qrData[3] == '+') {
        for (int i = 0; i < 3; i++) {
            taskArray[i] = qrData[i] - '0';
            taskArray[i + 3] = qrData[i + 4] - '0';
        }
    }
}

// int TaskManager::processColor() {
//     cv::Mat frame;
//     cap2 >> frame;
//     if (frame.empty()) {
//         return 0;
//     }
//
//     // 自适应直方图均衡化
//     cv::Mat lab;
//     cvtColor(frame, lab, cv::COLOR_BGR2Lab);
//     std::vector<cv::Mat> lab_planes(3);
//     split(lab, lab_planes);
//     cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE(2.0, cv::Size(8, 8));
//     cv::Mat dst;
//     clahe->apply(lab_planes[0], dst);
//     dst.copyTo(lab_planes[0]);
//     merge(lab_planes, lab);
//     cvtColor(lab, frame, cv::COLOR_Lab2BGR);
//
//     // 高斯模糊
//     cv::Mat blurred;
//     GaussianBlur(frame, blurred, cv::Size(7, 7), 0);
//
//     // 转换到HSV颜色空间
//     cv::Mat hsv;
//     cvtColor(blurred, hsv, cv::COLOR_BGR2HSV);
//
//     int colorCode = 0;    // 默认为0，表示没有检测到颜色
//     float maxRatio = 0.2; // 颜色检测阈值
//
//     // 处理每种颜色
//     for (auto const &range : colorRanges) {
//         // 颜色分割
//         cv::Mat mask;
//         inRange(hsv, range.lower, range.upper, mask);
//
//         // 形态学操作
//         cv::Mat kernel =
//             getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(7, 7));
//         morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
//         morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);
//
//         // 中值滤波去除噪点
//         medianBlur(mask, mask, 5);
//
//         // 计算ROI区域内的颜色占比
//         cv::Mat roiMask = mask(centerROI);
//         int colorPixels = countNonZero(roiMask);
//         float colorRatio =
//             (float)colorPixels / (centerROI.width * centerROI.height);
//
//         // 更新颜色代码
//         if (colorRatio > maxRatio) {
//             if (range.name == "red") {
//                 colorCode = 1;
//                 putText(frame, "RED", cv::Point(centerROI.x, centerROI.y -
//                 10),
//                         cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 255),
//                         2);
//             } else if (range.name == "green") {
//                 colorCode = 2;
//                 putText(
//                     frame, "GREEN",
//                     cv::Point(centerROI.x, centerROI.y + centerROI.height +
//                     25), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 255,
//                     0), 2);
//             } else if (range.name == "blue") {
//                 colorCode = 3;
//                 putText(frame, "BLUE",
//                         cv::Point(centerROI.x + centerROI.width + 10,
//                                   centerROI.y + centerROI.height / 2),
//                         cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255, 0, 0),
//                         2);
//             }
//         }
//
//         // 显示颜色掩码
//         std::string windowName = "Mask " + range.name;
//         putText(mask, "Ratio: " + std::to_string(colorRatio).substr(0, 4),
//                 cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.6,
//                 cv::Scalar(255), 1);
//         cv::imshow(windowName, mask);
//     }
//
//     // 绘制中心矩形区域
//     rectangle(frame, centerROI, cv::Scalar(0, 255, 255), 2);
//
//     // 显示颜色代码状态
//     std::string status = "Color Code: " + std::to_string(colorCode);
//     putText(frame, status, cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.7,
//             cv::Scalar(0, 255, 255), 2);
//
//     // 显示结果
//     cv::imshow("Color Detection", frame);
//
//     return colorCode;
// }

// int TaskManager::processColor() {
//     cv::Mat frame;
//     cap2 >> frame;
//     if (frame.empty()) {
//         return 0;
//     }
//
//     // 保存原始帧用于显示
//     cv::Mat displayFrame = frame.clone();
//
//     // 转换为灰度图
//     cv::Mat gray;
//     cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
//
//     // 高斯模糊减少噪声
//     cv::Mat blurred;
//     cv::GaussianBlur(gray, blurred, cv::Size(5, 5), 0);
//
//     // Canny边缘检测
//     cv::Mat edges;
//     cv::Canny(blurred, edges, 50, 150);
//
//     // 形态学操作增强边缘
//     cv::Mat kernel = getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(3,
//     3)); cv::morphologyEx(edges, edges, cv::MORPH_CLOSE, kernel);
//
//     // 查找轮廓
//     std::vector<std::vector<cv::Point>> contours;
//     cv::findContours(edges, contours, cv::RETR_EXTERNAL,
//                      cv::CHAIN_APPROX_SIMPLE);
//
//     // 用于存储检测到的圆的信息
//     std::vector<cv::Point2f> centers;
//     std::vector<float> radii;
//
//     for (const auto &contour : contours) {
//         // 计算面积和周长
//         double area = cv::contourArea(contour);
//         if (area < 900)
//             continue; // 过滤小面积
//
//         // 计算圆形度
//         double perimeter = cv::arcLength(contour, true);
//         double circularity = 4 * CV_PI * area / (perimeter * perimeter);
//         if (circularity < 0.4)
//             continue; // 确保是圆形
//
//         // 拟合圆
//         cv::Point2f center;
//         float radius;
//         cv::minEnclosingCircle(contour, center, radius);
//
//         // 验证半径范围（基于已知物料半径50mm）
//         if (radius < 30 || radius > 100)
//             continue;
//
//         centers.push_back(center);
//         radii.push_back(radius);
//     }
//     int colorCode = 0;
//     // 如果检测到圆形
//     if (!centers.empty()) {
//         // 选择最接近中心的圆
//         int bestIdx = 0;
//         float minDist = FLT_MAX;
//         for (size_t i = 0; i < centers.size(); i++) {
//             float dist = cv::norm(centers[i] - imageCenter);
//             if (dist < minDist) {
//                 minDist = dist;
//                 bestIdx = i;
//             }
//         }
//
//         // 计算实际距离
//         float physicalRadius = 50.0f; // 实际物料半径(mm)
//         float distanceScale = physicalRadius / radii[bestIdx];
//
//         // 计算相对于图像中心的位置
//         cv::Point2f relativePos = centers[bestIdx] - imageCenter;
//         float realX = relativePos.x * distanceScale;
//         float realY = -relativePos.y * distanceScale; // 注意Y轴方向转换
//
//         // 在图像上显示结果
//         cv::circle(displayFrame, centers[bestIdx], radii[bestIdx],
//                    cv::Scalar(0, 255, 0), 2);
//         cv::circle(displayFrame, centers[bestIdx], 3, cv::Scalar(0, 0,255),
//                    -1);
//
//         // 显示实际坐标
//         std::string coords = "(" + std::to_string(int(realX)) + "," +
//                              std::to_string(int(realY)) + ")mm";
//         cv::putText(displayFrame, coords,
//                     cv::Point(centers[bestIdx].x + 10,centers[bestIdx].y),
//                     cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 0),2);
//
//         // 返回颜色代码（这里需要根据实际情况判断颜色）
//         // 可以在检测到的圆形区域内取样本点判断颜色
//         cv::Mat roi = frame(cv::Rect(centers[bestIdx].x - radii[bestIdx] /2,
//                                      centers[bestIdx].y - radii[bestIdx] /2,
//                                      radii[bestIdx], radii[bestIdx]));
//
//         cv::Scalar meanColor = cv::mean(roi);
//         // 简单的颜色判断逻辑
//         if (meanColor[2] > meanColor[1] && meanColor[2] > meanColor[0]) {
//             colorCode =  1; // 红色
//         } else if (meanColor[1] > meanColor[0] && meanColor[1] >
//         meanColor[2]) {
//             colorCode = 2; // 绿色
//         } else if (meanColor[0] > meanColor[1] && meanColor[0] >
//         meanColor[2]) {
//             colorCode = 3; // 蓝色
//         }
//     }
//     cv::line(displayFrame, cv::Point(imageCenter.x - 10, imageCenter.y),
//              cv::Point(imageCenter.x + 10, imageCenter.y),
//              cv::Scalar(0, 0, 255), 2);
//     cv::line(displayFrame, cv::Point(imageCenter.x, imageCenter.y - 10),
//              cv::Point(imageCenter.x, imageCenter.y + 10),
//              cv::Scalar(0, 0, 255), 2);
//     cv::namedWindow("Color Detection", cv::WINDOW_AUTOSIZE);
//     cv::namedWindow("Edges", cv::WINDOW_AUTOSIZE);
//     cv::imshow("Edges", edges);
//     cv::imshow("Color Detection", displayFrame);
//
//     return colorCode; // 未检测到物料或无法判断颜色
// }

void TaskManager::processColor() {
    cv::Mat frame;
    cap2 >> frame;
    if (frame.empty()) {
        return;
    }

    // 自适应直方图均衡化
    cv::Mat lab;
    cvtColor(frame, lab, cv::COLOR_BGR2Lab);
    std::vector<cv::Mat> lab_planes(3);
    split(lab, lab_planes);
    cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE(2.0, cv::Size(8, 8));
    cv::Mat dst;
    clahe->apply(lab_planes[0], dst);
    dst.copyTo(lab_planes[0]);
    merge(lab_planes, lab);
    cvtColor(lab, frame, cv::COLOR_Lab2BGR);

    // 高斯模糊
    cv::Mat blurred;
    GaussianBlur(frame, blurred, cv::Size(7, 7), 0);

    // 转换到HSV颜色空间
    cv::Mat hsv;
    cvtColor(blurred, hsv, cv::COLOR_BGR2HSV);

    int colorCode = 0;
    float minDistance = FLT_MAX;
    std::string closestColor;
    cv::Point2f closestPos;

    // 显示图像中心十字线
    cv::line(frame, cv::Point(imageCenter.x - 10, imageCenter.y),
             cv::Point(imageCenter.x + 10, imageCenter.y),
             cv::Scalar(0, 0, 255), 2);
    cv::line(frame, cv::Point(imageCenter.x, imageCenter.y - 10),
             cv::Point(imageCenter.x, imageCenter.y + 10),
             cv::Scalar(0, 0, 255), 2);

    // 处理每种颜色
    for (auto const &range : colorRanges) {
        // 颜色分割
        cv::Mat mask;
        inRange(hsv, range.lower, range.upper, mask);

        // 形态学操作
        cv::Mat kernel =
            getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(7, 7));
        morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
        morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);

        // 中值滤波去除噪点
        medianBlur(mask, mask, 5);

        // 查找轮廓
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(mask, contours, cv::RETR_EXTERNAL,
                         cv::CHAIN_APPROX_SIMPLE);

        // 找到最大的轮廓
        if (!contours.empty()) {
            int maxIdx = 0;
            double maxArea = 0;
            for (size_t i = 0; i < contours.size(); i++) {
                double area = cv::contourArea(contours[i]);
                if (area > maxArea) {
                    maxArea = area;
                    maxIdx = i;
                }
            }

            if (maxArea > 800) {
                cv::Moments m = cv::moments(contours[maxIdx]);
                if (m.m00 != 0) {
                    cv::Point2f center(m.m10 / m.m00, m.m01 / m.m00);
                    cv::Point2f relativePos = center - imageCenter;
                    float distance = cv::norm(relativePos);

                    // 更新最近的物块信息
                    if (distance < minDistance) {
                        minDistance = distance;
                        closestColor = range.name;
                        closestPos = relativePos;
                        colorCode = (range.name == "red")     ? 1
                                    : (range.name == "green") ? 2
                                    : (range.name == "blue")  ? 3
                                                              : 0;
                    }

                    // 在图像上显示所有检测到的物块
                    cv::circle(frame, center, 5, range.color, -1);
                    cv::line(frame, center, cv::Point(imageCenter), range.color,
                             1);
                }
            }
        }
        cv::imshow("Mask " + range.name, mask);
    }

    // 检查是否稳定
    if (minDistance != FLT_MAX) {
        if (std::abs(minDistance - lastDistance) < MOVEMENT_THRESHOLD) {
            stableCount++;
            if (stableCount >= STABLE_FRAMES) {
                // 物块稳定，输出信息
                // std::cout << "Stable block detected:\n"
                //           << "  Color: " << closestColor << "\n"
                //           << "  Position: (" << std::fixed
                //           << std::setprecision(1) << closestPos.x << ", "
                //           << closestPos.y << ")\n"
                //           << "  Distance: " << std::setprecision(1)
                //           << minDistance << "px\n"
                //           << "-------------------\n";
                taskArray[6] = colorCode;
                taskArray[7] = closestPos.x * 180 / 280 + 128;
                taskArray[8] = closestPos.y * 180 / 280 + 128;

                std::cout << "x= " <<taskArray[7]-128 <<", y= "<<taskArray[8] -128<<"\n";

                // 在图像上标记稳定的物块
                cv::Point2f stableCenter = imageCenter + closestPos;
                cv::circle(frame, stableCenter, 8, cv::Scalar(255, 255, 255),
                           2);
                std::string stableStr = "Stable: " + closestColor;
                cv::putText(frame, stableStr, cv::Point(10, 60),
                            cv::FONT_HERSHEY_SIMPLEX, 0.7,
                            cv::Scalar(255, 255, 255), 2);
            }
        } else {
            stableCount = 0; // 重置计数器
                taskArray[6] = 0;
                taskArray[7] = 0;
                taskArray[8] = 0;
        }
        lastDistance = minDistance; // 更新上一帧的距离
    }

    cv::imshow("Color Detection", frame);
    // return colorCode;
}

void TaskManager::processColor_bi() {
    cv::Mat frame;
    cap2 >> frame;
    if (frame.empty()) {
        return;
    }

    // 自适应直方图均衡化
    cv::Mat lab;
    cvtColor(frame, lab, cv::COLOR_BGR2Lab);
    std::vector<cv::Mat> lab_planes(3);
    split(lab, lab_planes);
    cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE(2.0, cv::Size(8, 8));
    cv::Mat dst;
    clahe->apply(lab_planes[0], dst);
    dst.copyTo(lab_planes[0]);
    merge(lab_planes, lab);
    cvtColor(lab, frame, cv::COLOR_Lab2BGR);

    // 高斯模糊
    cv::Mat blurred;
    GaussianBlur(frame, blurred, cv::Size(7, 7), 0);

    // 转换到HSV颜色空间
    cv::Mat hsv;
    cvtColor(blurred, hsv, cv::COLOR_BGR2HSV);

    int colorCode = 0;
    float minDistance = FLT_MAX;
    std::string closestColor;
    cv::Point2f closestPos;

    // 显示图像中心十字线
    cv::line(frame, cv::Point(imageCenter.x - 10, imageCenter.y),
             cv::Point(imageCenter.x + 10, imageCenter.y),
             cv::Scalar(0, 0, 255), 2);
    cv::line(frame, cv::Point(imageCenter.x, imageCenter.y - 10),
             cv::Point(imageCenter.x, imageCenter.y + 10),
             cv::Scalar(0, 0, 255), 2);

    // 处理每种颜色
    for (auto const &range : colorRanges) {
        // 颜色分割
        cv::Mat mask;
        inRange(hsv, range.lower, range.upper, mask);

        // 形态学操作
        cv::Mat kernel =
            getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(7, 7));
        morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
        morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);

        // 中值滤波去除噪点
        medianBlur(mask, mask, 5);

        // 查找轮廓
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(mask, contours, cv::RETR_EXTERNAL,
                         cv::CHAIN_APPROX_SIMPLE);

        // 找到最大的轮廓
        if (!contours.empty()) {
            int maxIdx = 0;
            double maxArea = 0;
            for (size_t i = 0; i < contours.size(); i++) {
                double area = cv::contourArea(contours[i]);
                if (area > maxArea) {
                    maxArea = area;
                    maxIdx = i;
                }
            }

            if (maxArea > 800) {
                cv::Moments m = cv::moments(contours[maxIdx]);
                if (m.m00 != 0) {
                    cv::Point2f center(m.m10 / m.m00, m.m01 / m.m00);
                    cv::Point2f relativePos = center - imageCenter;
                    float distance = cv::norm(relativePos);

                    // 更新最近的物块信息
                    if (distance < minDistance) {
                        minDistance = distance;
                        closestColor = range.name;
                        closestPos = relativePos;
                        colorCode = (range.name == "red")     ? 1
                                    : (range.name == "green") ? 2
                                    : (range.name == "blue")  ? 3
                                                              : 0;
                    }

                    // 在图像上显示所有检测到的物块
                    cv::circle(frame, center, 5, range.color, -1);
                    cv::line(frame, center, cv::Point(imageCenter), range.color,
                             1);
                }
            }
        }
        else{
            taskArray[7] = -128;
            taskArray[8] = -128;
        }
        cv::imshow("Mask " + range.name, mask);
    }

    // 检查是否稳定
    if (minDistance != FLT_MAX) {
                taskArray[6] = colorCode;
                taskArray[7] = closestPos.x * 180 / 280 + 128;
                taskArray[8] = closestPos.y * 180 / 280 + 128;

                std::cout << "x= " <<taskArray[7]-128 <<", y= "<<taskArray[8] -128<<"\n";

                // 在图像上标记稳定的物块
                cv::Point2f stableCenter = imageCenter + closestPos;
                cv::circle(frame, stableCenter, 8, cv::Scalar(255, 255, 255),
                           2);
                std::string stableStr = "Stable: " + closestColor;
                cv::putText(frame, stableStr, cv::Point(10, 60),
                            cv::FONT_HERSHEY_SIMPLEX, 0.7,
                            cv::Scalar(255, 255, 255), 2);
    }

    cv::imshow("Color Detection", frame);
    // return colorCode;
}
