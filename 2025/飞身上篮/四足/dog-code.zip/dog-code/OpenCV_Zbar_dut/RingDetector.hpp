#pragma once
#include <deque>
#include <opencv2/opencv.hpp>
#include <optional>

class RingDetector {
public:
  RingDetector(cv::VideoCapture &camera);
  ~RingDetector();
  std::optional<cv::Point2f> processFrame();

private:
  cv::VideoCapture &cap;
  cv::Mat frame;
  cv::Point2f imageCenter;
  std::vector<cv::Point2f> ringCenters;
  std::vector<cv::Point2f> lastCenters;

  struct Parameters {
    static int cannyThreshold1;
    static int cannyThreshold2;
    static int minRadius;
    static int maxRadius;
    static int minDist;
    static int dilateSize;
    static int erodeSize;
    static int blurSize;
    static int claheClipLimit;
    static int edgeThreshold;
  } params;

  void createTrackbars();
  void showResults();
};


