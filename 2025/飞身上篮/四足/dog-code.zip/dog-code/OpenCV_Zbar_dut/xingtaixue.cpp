//
// Created by zgh on 2025/2/20.
//
#include <opencv2/opencv.hpp>
#include <iostream>
#include <opencv2/videoio.hpp>
#include <vector>

using namespace cv;
using namespace std;

class RingDetector {
private:
    Mat frame;
    Point2f imageCenter;
    vector<Point2f> ringCenters;

public:
    RingDetector() {
        VideoCapture cap(2,cv::CAP_V4L2);
        if (!cap.isOpened()) {
            cout << "无法打开摄像头" << endl;
            return;
        }

        cap.read(frame);
        imageCenter = Point2f(frame.cols / 2.0f, frame.rows / 2.0f);

        namedWindow("Parameters");
        createTrackbars();

        while (true) {
            cap.read(frame);
            if (frame.empty()) break;

            processFrame();
            showResults();

            if (waitKey(1) == 'q') break;
        }

        cap.release();
        destroyAllWindows();
    }

private:
    struct Parameters {
        static int binaryThreshold;
        static int minRadius;
        static int maxRadius;
        static int minDist;
        static int dilateSize;
        static int erodeSize;
    } params;

    void createTrackbars() {
        createTrackbar("Binary Threshold", "Parameters", &params.binaryThreshold, 255);
        createTrackbar("Min Radius", "Parameters", &params.minRadius, 100);
        createTrackbar("Max Radius", "Parameters", &params.maxRadius, 200);
        createTrackbar("Min Distance", "Parameters", &params.minDist, 200);
        createTrackbar("Dilate Size", "Parameters", &params.dilateSize, 20);
        createTrackbar("Erode Size", "Parameters", &params.erodeSize, 20);
    }

    void processFrame() {
        // 转换为灰度图
        Mat gray;
        cvtColor(frame, gray, COLOR_BGR2GRAY);

        // 二值化
        Mat binary;
        threshold(gray, binary, params.binaryThreshold, 255, THRESH_BINARY_INV);

        // 形态学操作连接虚线
        Mat morphology;
        int dilateSize = params.dilateSize * 2 + 1;
        int erodeSize = params.erodeSize * 2 + 1;

        // 使用线性结构元素进行膨胀，连接虚线
        Mat dilateElement = getStructuringElement(MORPH_RECT, Size(dilateSize, dilateSize));
        dilate(binary, morphology, dilateElement);

        // 使用圆形结构元素进行腐蚀，保持圆形特征
        Mat erodeElement = getStructuringElement(MORPH_ELLIPSE, Size(erodeSize, erodeSize));
        erode(morphology, morphology, erodeElement);

        // 找轮廓
        vector<vector<Point>> contours;
        findContours(morphology, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        // 分析每个轮廓
        ringCenters.clear();
        for (const auto& contour : contours) {
            // 计算轮廓的基本特征
            double area = contourArea(contour);
            if (area < 1000) continue; // 过滤小区域

            // 找到最小外接圆
            Point2f center;
            float radius;
            minEnclosingCircle(contour, center, radius);

            // 计算轮廓的圆形度
            double perimeter = arcLength(contour, true);
            double circularity = 4 * CV_PI * area / (perimeter * perimeter);

            // 计算轮廓的矩
            Moments m = moments(contour);
            Point2f centroid(m.m10/m.m00, m.m01/m.m00);

            // 验证是否为圆环
            if (circularity > 0.8) { // 圆形度阈值
                // 检查是否有内部轮廓（空心）
                Mat mask = Mat::zeros(morphology.size(), CV_8UC1);
                drawContours(mask, vector<vector<Point>>{contour}, 0, Scalar(255), -1);
                int whitePixels = countNonZero(mask);
                float filledRatio = whitePixels / area;

                if (filledRatio < 0.9) { // 确保是空心的
                    ringCenters.push_back(center);

                    // 在原图上标记
                    circle(frame, center, 3, Scalar(0, 0, 255), -1);
                    circle(frame, center, radius, Scalar(0, 255, 0), 2);

                    // 计算并显示相对坐标
                    Point2f relativePos = center - imageCenter;
                    putText(frame,
                            "(" + to_string(int(relativePos.x)) + "," + to_string(int(relativePos.y)) + ")",
                            Point(center.x + 10, center.y),
                            FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 0), 1);

                    cout << "圆环中心相对坐标: ("
                         << relativePos.x << ", " << relativePos.y << ")" << endl;
                }
            }
        }

        // 显示处理过程
        imshow("Binary", binary);
        imshow("Morphology", morphology);
    }

    void showResults() {
        // 绘制图像中心十字线
        line(frame,
             Point(imageCenter.x - 10, imageCenter.y),
             Point(imageCenter.x + 10, imageCenter.y),
             Scalar(0, 0, 255), 2);
        line(frame,
             Point(imageCenter.x, imageCenter.y - 10),
             Point(imageCenter.x, imageCenter.y + 10),
             Scalar(0, 0, 255), 2);

        imshow("Ring Detection", frame);
    }
};

// 初始化静态成员变量
int RingDetector::Parameters::binaryThreshold = 128;
int RingDetector::Parameters::minRadius = 20;
int RingDetector::Parameters::maxRadius = 100;
int RingDetector::Parameters::minDist = 50;
int RingDetector::Parameters::dilateSize = 3;
int RingDetector::Parameters::erodeSize = 3;

int main() {
    RingDetector detector;
    return 0;
}
