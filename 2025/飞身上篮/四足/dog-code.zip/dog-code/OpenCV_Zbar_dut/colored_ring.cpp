#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <opencv2/videoio.hpp>
#include <ostream>
#include <vector>

using namespace cv;
using namespace std;

class RingDetector {
private:
    Mat frame;
    Point2f imageCenter;
    vector<Point2f> ringCenters;
    vector<Point2f> lastCenters;  // 用于时间平滑

public:
    RingDetector() {
        VideoCapture cap(2, cv::CAP_V4L2);
        if (!cap.isOpened()) {
            cout << "无法打开摄像头" << endl;
            return;
        }

        // cap.set(CAP_PROP_AUTO_EXPOSURE, 0);  // 关闭自动曝光
        // cap.set(CAP_PROP_EXPOSURE, 100);     // 设置固定曝光时间
        // cap.set(CAP_PROP_AUTO_WB, 0);        // 关闭自动白平衡


        cap.read(frame);
        imageCenter = Point2f(frame.cols / 2.0f, frame.rows / 2.0f);

        namedWindow("Parameters");
        createTrackbars();

        while (true) {
            cap.read(frame);
            if (frame.empty()) break;

            processFrame();
            showResults();

            if (waitKey(1) == 'q') break;
        }

        cap.release();
        destroyAllWindows();
    }

private:
    struct Parameters {
        static int cannyThreshold1;
        static int cannyThreshold2;
        static int minRadius;
        static int maxRadius;
        static int minDist;
        static int dilateSize;
        static int erodeSize;
        static int blurSize;
        static int claheClipLimit;
        static int edgeThreshold;
    } params;

    void createTrackbars() {
        createTrackbar("Canny Threshold1", "Parameters", &params.cannyThreshold1, 255);
        createTrackbar("Canny Threshold2", "Parameters", &params.cannyThreshold2, 255);
        createTrackbar("Min Radius", "Parameters", &params.minRadius, 100);
        createTrackbar("Max Radius", "Parameters", &params.maxRadius, 200);
        createTrackbar("Min Distance", "Parameters", &params.minDist, 200);
        createTrackbar("Dilate Size", "Parameters", &params.dilateSize, 20);
        createTrackbar("Erode Size", "Parameters", &params.erodeSize, 20);
        createTrackbar("Blur Size", "Parameters", &params.blurSize, 20);
        createTrackbar("CLAHE Clip Limit", "Parameters", &params.claheClipLimit, 10);
        createTrackbar("Edge Threshold", "Parameters", &params.edgeThreshold, 255);
    }

    void processFrame() {
        // 1. 自适应直方图均衡化预处理
        Mat lab;
        cvtColor(frame, lab, COLOR_BGR2Lab);
        vector<Mat> lab_planes(3);
        split(lab, lab_planes);
        Ptr<CLAHE> clahe = createCLAHE(params.claheClipLimit, Size(8,8));
        Mat dst;
        clahe->apply(lab_planes[0], dst);
        dst.copyTo(lab_planes[0]);
        merge(lab_planes, lab);
        cvtColor(lab, frame, COLOR_Lab2BGR);

        // 2. 转换为灰度图
        Mat gray;
        cvtColor(frame, gray, COLOR_BGR2GRAY);
        
        // 3. 使用双边滤波
        Mat blurred;
        bilateralFilter(gray, blurred, -1, 50, 5);

        // 4. 自适应阈值分割
        Mat binary;
        adaptiveThreshold(blurred, binary, 255,
                         ADAPTIVE_THRESH_GAUSSIAN_C,
                         THRESH_BINARY,
                         2 * params.blurSize + 1,
                         2);

        // 5. 多尺度Canny边缘检测
        Mat edges;
        vector<Mat> edgesList;
        for(int i = -10; i <= 10; i += 10) {
            Mat edge;
            Canny(blurred, edge, 
                  max(0, params.cannyThreshold1 + i),
                  max(0, params.cannyThreshold2 + i));
            edgesList.push_back(edge);
        }
        
        edges = edgesList[0];
        for(size_t i = 1; i < edgesList.size(); i++) {
            bitwise_or(edges, edgesList[i], edges);
        }

        // 6. 形态学操作
        Mat morphology = edges.clone();
        
        int dilateSize = params.dilateSize * 2 + 1;
        Mat dilateElement = getStructuringElement(MORPH_ELLIPSE, Size(dilateSize, dilateSize));
        dilate(morphology, morphology, dilateElement);

        int erodeSize = params.erodeSize * 2 + 1;
        Mat erodeElement = getStructuringElement(MORPH_ELLIPSE, Size(erodeSize, erodeSize));
        erode(morphology, morphology, erodeElement);

        // 7. 轮廓检测
        vector<vector<Point>> contours;
        vector<Vec4i> hierarchy;
        findContours(morphology, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        vector<Point2f> currentCenters;

        for (const auto& contour : contours) {
            double area = contourArea(contour);
            if (area < 500) continue;

            // 8. 圆形度计算
            double perimeter = arcLength(contour, true);
            double circularity = 4 * CV_PI * area / (perimeter * perimeter);
            
            if (circularity < 0.3) continue;

            // 9. 椭圆拟合
            if (contour.size() > 5) {
                RotatedRect ellipse = fitEllipse(contour);
                float ratio = min(ellipse.size.width, ellipse.size.height) / 
                             max(ellipse.size.width, ellipse.size.height);
                if (ratio < 0.7) continue;
            }

            Point2f center;
            float radius;
            minEnclosingCircle(contour, center, radius);

            if (radius < params.minRadius || radius > params.maxRadius) continue;

            // 10. 验证边缘强度
            float avgEdgeStrength = 0;
            int count = 0;
            for (int angle = 0; angle < 360; angle += 10) {
                float radian = angle * CV_PI / 180.0;
                Point2f edgePoint(
                    center.x + radius * cos(radian),
                    center.y + radius * sin(radian)
                );
                
                if (edgePoint.x >= 0 && edgePoint.x < edges.cols &&
                    edgePoint.y >= 0 && edgePoint.y < edges.rows) {
                    avgEdgeStrength += edges.at<uchar>(edgePoint.y, edgePoint.x);
                    count++;
                }
            }
            avgEdgeStrength /= count;
            if (avgEdgeStrength < params.edgeThreshold) continue;

            currentCenters.push_back(center);

            // 11. 时间平滑
            Point2f smoothedCenter = center;
            if (!lastCenters.empty()) {
                float minDist = FLT_MAX;
                Point2f* nearestCenter = nullptr;
                for (auto& lastCenter : lastCenters) {
                    float dist = norm(center - lastCenter);
                    if (dist < minDist) {
                        minDist = dist;
                        nearestCenter = &lastCenter;
                    }
                }
                
                if (nearestCenter && minDist < 50) {
                    smoothedCenter = *nearestCenter * 0.3f + center * 0.7f;
                }
            }

            // 12. 绘制结果
            circle(frame, smoothedCenter, radius, Scalar(0, 255, 0), 2);
            circle(frame, smoothedCenter, 3, Scalar(0, 0, 255), -1);

            Point2f relativePos = smoothedCenter - imageCenter;
            float physicalRadius = 105.0f;  // 实际色环半径(mm)
            float distanceScale = physicalRadius / radius;
            
            putText(frame,
                    "(" + to_string(int(relativePos.x * distanceScale)) + 
                    "," + to_string(int(relativePos.y * distanceScale)) + ")",
                    Point(smoothedCenter.x + 10, smoothedCenter.y),
                    FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 0), 1);

            cout << "色环中心相对坐标(mm): ("
                 << relativePos.x * distanceScale << ", " 
                 << relativePos.y * distanceScale << ")" << endl;
        }

        lastCenters = currentCenters;

        // 13. 显示中间结果
        imshow("Binary", binary);
        imshow("Edges", edges);
        imshow("Morphology", morphology);
    }

    void showResults() {
        // 绘制图像中心十字线
        line(frame,
             Point(imageCenter.x - 10, imageCenter.y),
             Point(imageCenter.x + 10, imageCenter.y),
             Scalar(0, 0, 255), 2);
        line(frame,
             Point(imageCenter.x, imageCenter.y - 10),
             Point(imageCenter.x, imageCenter.y + 10),
             Scalar(0, 0, 255), 2);

        imshow("Ring Detection", frame);
    }
};

// 初始化静态成员变量
int RingDetector::Parameters::cannyThreshold1 = 50;
int RingDetector::Parameters::cannyThreshold2 = 150;
int RingDetector::Parameters::minRadius = 50;
int RingDetector::Parameters::maxRadius = 150;
int RingDetector::Parameters::minDist = 50;
int RingDetector::Parameters::dilateSize = 6;
int RingDetector::Parameters::erodeSize = 10;
int RingDetector::Parameters::blurSize = 5;
int RingDetector::Parameters::claheClipLimit = 3;
int RingDetector::Parameters::edgeThreshold = 30;

int main() {
    RingDetector detector;
    return 0;
}
