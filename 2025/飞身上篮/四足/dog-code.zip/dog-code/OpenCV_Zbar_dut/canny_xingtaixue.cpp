//
// Created by zgh on 2025/2/20.
//
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <opencv2/videoio.hpp>
#include <ostream>
#include <vector>

using namespace cv;
using namespace std;

class RingDetector {
private:
    Mat frame;
    Point2f imageCenter;
    vector<Point2f> ringCenters;

public:
    RingDetector() {
        VideoCapture cap(2,cv::CAP_V4L2);
        if (!cap.isOpened()) {
            cout << "无法打开摄像头" << endl;
            return;
        }

        cap.read(frame);
        imageCenter = Point2f(frame.cols / 2.0f, frame.rows / 2.0f);

        namedWindow("Parameters");
        createTrackbars();

        while (true) {
            cap.read(frame);
            if (frame.empty()) break;

            processFrame();
            showResults();

            if (waitKey(1) == 'q') break;
        }

        cap.release();
        destroyAllWindows();
    }

private:
    struct Parameters {
        static int cannyThreshold1;
        static int cannyThreshold2;
        static int minRadius;
        static int maxRadius;
        static int minDist;
        static int dilateSize;
        static int erodeSize;
        static int blurSize;
    } params;

    void createTrackbars() {
        createTrackbar("Canny Threshold1", "Parameters", &params.cannyThreshold1, 255);
        createTrackbar("Canny Threshold2", "Parameters", &params.cannyThreshold2, 255);
        createTrackbar("Min Radius", "Parameters", &params.minRadius, 100);
        createTrackbar("Max Radius", "Parameters", &params.maxRadius, 200);
        createTrackbar("Min Distance", "Parameters", &params.minDist, 200);
        createTrackbar("Dilate Size", "Parameters", &params.dilateSize, 20);
        createTrackbar("Erode Size", "Parameters", &params.erodeSize, 20);
        createTrackbar("Blur Size", "Parameters", &params.blurSize, 20);
    }

//    void processFrame() {
//        // 转换为灰度图
//        Mat gray;
//        cvtColor(frame, gray, COLOR_BGR2GRAY);
//
//        // 高斯模糊
//        int blurSize = params.blurSize * 2 + 1;
//        GaussianBlur(gray, gray, Size(blurSize, blurSize), 0);
//
//        // Canny边缘检测
//        Mat edges;
//        Canny(gray, edges, params.cannyThreshold1, params.cannyThreshold2);
//
//        // 形态学操作处理虚线
//        Mat morphology = edges.clone();
//
//        // 使用线性结构元素进行膨胀，连接虚线
//        int dilateSize = params.dilateSize * 2 + 1;
//        Mat dilateElement = getStructuringElement(MORPH_RECT, Size(dilateSize, dilateSize));
//        dilate(morphology, morphology, dilateElement);
//
//        // 使用圆形结构元素进行腐蚀，保持圆形特征
//        int erodeSize = params.erodeSize * 2 + 1;
//        Mat erodeElement = getStructuringElement(MORPH_ELLIPSE, Size(erodeSize, erodeSize));
//        erode(morphology, morphology, erodeElement);
//
//        // 霍夫圆变换检测圆
//        vector<Vec3f> circles;
//        HoughCircles(gray, circles, HOUGH_GRADIENT, 1,
//                     params.minDist,  // 最小圆心距离
//                     params.cannyThreshold2, // Canny高阈值
//                     30,             // 累加器阈值
//                     params.minRadius,      // 最小半径
//                     params.maxRadius       // 最大半径
//        );
//
//        // 对检测到的圆进行分组（找到同心圆）
//        vector<vector<Vec3f>> concentricCircles;
//        for (const auto& circle : circles) {
//            Point2f center(circle[0], circle[1]);
//            float radius = circle[2];
//
//            // 验证圆是否在边缘上
//            int count = 0;
//            int totalPoints = 0;
//            for (int angle = 0; angle < 360; angle += 10) {
//                float radian = angle * CV_PI / 180.0;
//                int x = center.x + radius * cos(radian);
//                int y = center.y + radius * sin(radian);
//
//                if (x >= 0 && x < morphology.cols && y >= 0 && y < morphology.rows) {
//                    totalPoints++;
//                    if (morphology.at<uchar>(y, x) > 0) {
//                        count++;
//                    }
//                }
//            }
//
//            float edgeRatio = count / (float)totalPoints;
//            if (edgeRatio < 0.3) continue;  // 如果圆周上的边缘点太少，跳过
//
//            bool found = false;
//            // 检查是否属于现有的同心圆组
//            for (auto& group : concentricCircles) {
//                Point2f groupCenter(group[0][0], group[0][1]);
//                float distance = norm(center - groupCenter);
//                if (distance < 20) {  // 允许的圆心偏差
//                    group.push_back(circle);
//                    found = true;
//                    break;
//                }
//            }
//
//            // 如果不属于任何组，创建新组
//            if (!found) {
//                concentricCircles.push_back({circle});
//            }
//        }
//
//        // 只保留包含多个圆的组（同心圆环）
//        ringCenters.clear();
//        for (const auto& group : concentricCircles) {
//            if (group.size() >= 2) {  // 至少需要2个圆才构成圆环
//                Point2f center(group[0][0], group[0][1]);
//                ringCenters.push_back(center);
//
//                // 在原图上标记
//                for (const auto& circle : group) {
//                    Point2f circleCenter(circle[0], circle[1]);
//                    float radius = circle[2];
//                    cv::circle(frame, circleCenter, radius, Scalar(0, 255, 0), 2);
//                }
//
//                // 标记圆心
//                circle(frame, center, 3, Scalar(0, 0, 255), -1);
//
//                // 计算并显示相对坐标
//                Point2f relativePos = center - imageCenter;
//                putText(frame,
//                        "(" + to_string(int(relativePos.x)) + "," + to_string(int(relativePos.y)) + ")",
//                        Point(center.x + 10, center.y),
//                        FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 0), 1);
//
//                cout << "圆环中心相对坐标: ("
//                     << relativePos.x << ", " << relativePos.y << ")" << endl;
//            }
//        }
//
//        // 显示处理过程
//        imshow("Edges", edges);
//        imshow("Morphology", morphology);
//    }
   

    void processFrame() {
        // 转换为灰度图
        Mat gray;
        cvtColor(frame, gray, COLOR_BGR2GRAY);

        // 高斯模糊
        int blurSize = params.blurSize * 2 + 1;
        GaussianBlur(gray, gray, Size(blurSize, blurSize), 0);

        // Canny边缘检测
        Mat edges;
        Canny(gray, edges, params.cannyThreshold1, params.cannyThreshold2);

        // 形态学操作
        Mat morphology = edges.clone();

        // 膨胀操作，连接边缘
        int dilateSize = params.dilateSize * 2 + 1;
        Mat dilateElement = getStructuringElement(MORPH_RECT, Size(dilateSize, dilateSize));
        dilate(morphology, morphology, dilateElement);

        // 腐蚀操作，保持形状
        int erodeSize = params.erodeSize * 2 + 1;
        Mat erodeElement = getStructuringElement(MORPH_ELLIPSE, Size(erodeSize, erodeSize));
        erode(morphology, morphology, erodeElement);

        // 找轮廓
        vector<vector<Point>> contours;
        vector<Vec4i> hierarchy;
        findContours(morphology, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        // 处理每个轮廓
        for (const auto& contour : contours) {
            // 计算轮廓面积，过滤小区域
            double area = contourArea(contour);
            if (area < 1000) continue;  // 可调整此阈值

            // 计算轮廓的圆形度
            double perimeter = arcLength(contour, true);
            double circularity = 4 * CV_PI * area / (perimeter * perimeter);

            // 如果圆形度太低，跳过
            if (circularity < 0.6) continue;  // 可调整此阈值

            // 找到最小外接圆
            Point2f center;
            float radius;
            minEnclosingCircle(contour, center, radius);

            // 验证半径是否在合理范围内
            if (radius < params.minRadius || radius > params.maxRadius) continue;

            // 在原图上标记
            circle(frame, center, radius, Scalar(0, 255, 0), 2);
            cout<< "radius: " <<radius<<endl;
            circle(frame, center, 3, Scalar(0, 0, 255), -1);

            // 计算并显示相对坐标
            Point2f relativePos = center - imageCenter;
            putText(frame,
                    "(" + to_string(int(relativePos.x)) + "," + to_string(int(relativePos.y)) + ")",
                    Point(center.x + 10, center.y),
                    FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 0), 1);

            cout << "色环中心相对坐标: ("
                 << (float)relativePos.x * (float)105 / (float)radius  << ", " << (float)relativePos.y * (float)105 / (float)radius << ")" << endl;
        }

        // 显示处理过程
        imshow("Edges", edges);
        imshow("Morphology", morphology);
    }
    void showResults() {
        // 绘制图像中心十字线
        line(frame,
             Point(imageCenter.x - 10, imageCenter.y),
             Point(imageCenter.x + 10, imageCenter.y),
             Scalar(0, 0, 255), 2);
        line(frame,
             Point(imageCenter.x, imageCenter.y - 10),
             Point(imageCenter.x, imageCenter.y + 10),
             Scalar(0, 0, 255), 2);

        imshow("Ring Detection", frame);
    }
};

// 初始化静态成员变量
int RingDetector::Parameters::cannyThreshold1 = 0;
int RingDetector::Parameters::cannyThreshold2 = 20;
int RingDetector::Parameters::minRadius = 50;
int RingDetector::Parameters::maxRadius = 150;
int RingDetector::Parameters::minDist = 50;
int RingDetector::Parameters::dilateSize = 3;
int RingDetector::Parameters::erodeSize = 10;
int RingDetector::Parameters::blurSize = 5;

int main() {
    RingDetector detector;
    return 0;
}

//#include <opencv2/opencv.hpp>
//#include <opencv2/highgui/highgui.hpp>
//#include <opencv2/imgproc/imgproc.hpp>
//#include <iostream>
//#include <vector>
//
//using namespace cv;
//using namespace std;
//
//class RingDetector {
//private:
//    Mat frame;
//    Point2f imageCenter;
//
//public:
//    RingDetector() {
//        VideoCapture cap(2);
//        if (!cap.isOpened()) {
//            cout << "无法打开摄像头" << endl;
//            return;
//        }
//
//        cap.read(frame);
//        imageCenter = Point2f(frame.cols / 2.0f, frame.rows / 2.0f);
//
//        namedWindow("Parameters");
//        createTrackbars();
//
//        while (true) {
//            cap.read(frame);
//            if (frame.empty()) break;
//
//            processFrame();
//
//            if (waitKey(1) == 'q') break;
//        }
//
//        cap.release();
//        destroyAllWindows();
//    }
//
//private:
//    struct Parameters {
//        static int cannyThreshold1;
//        static int cannyThreshold2;
//        static int minRadius;
//        static int maxRadius;
//        static int dilateSize;
//        static int erodeSize;
//        static int blurSize;
//        static int houghThreshold;    // 霍夫圆检测的累加器阈值
//    } params;
//
//    void createTrackbars() {
//        createTrackbar("Canny Threshold1", "Parameters", &params.cannyThreshold1, 255);
//        createTrackbar("Canny Threshold2", "Parameters", &params.cannyThreshold2, 255);
//        createTrackbar("Min Radius", "Parameters", &params.minRadius, 100);
//        createTrackbar("Max Radius", "Parameters", &params.maxRadius, 200);
//        createTrackbar("Dilate Size", "Parameters", &params.dilateSize, 20);
//        createTrackbar("Erode Size", "Parameters", &params.erodeSize, 20);
//        createTrackbar("Blur Size", "Parameters", &params.blurSize, 20);
//        createTrackbar("Hough Threshold", "Parameters", &params.houghThreshold, 100);
//    }
//
//    void processFrame() {
//        // 转换为灰度图
//        Mat gray;
//        cvtColor(frame, gray, COLOR_BGR2GRAY);
//
//        // 高斯模糊
//        int blurSize = params.blurSize * 2 + 1;
//        GaussianBlur(gray, gray, Size(blurSize, blurSize), 0);
//
//        // 形态学操作处理虚线
//        Mat morphology = gray.clone();
//
//        // 使用线性结构元素进行膨胀，连接虚线
//        int dilateSize = params.dilateSize * 2 + 1;
//        Mat dilateElement = getStructuringElement(MORPH_RECT, Size(dilateSize, dilateSize));
//        dilate(morphology, morphology, dilateElement);
//
//        // 使用圆形结构元素进行腐蚀，保持圆形特征
//        int erodeSize = params.erodeSize * 2 + 1;
//        Mat erodeElement = getStructuringElement(MORPH_ELLIPSE, Size(erodeSize, erodeSize));
//        erode(morphology, morphology, erodeElement);
//
//        // Canny边缘检测
//        Mat edges;
//        Canny(morphology, edges, params.cannyThreshold1, params.cannyThreshold2);
//
//        // 霍夫圆变换检测圆
//        vector<Vec3f> circles;
//        HoughCircles(morphology, circles, HOUGH_GRADIENT, 1,
//                     20,  // 最小圆心距离
//                     params.cannyThreshold2, // Canny高阈值
//                     params.houghThreshold,  // 累加器阈值
//                     params.minRadius,       // 最小半径
//                     params.maxRadius        // 最大半径
//        );
//
//        // 按半径排序
//        sort(circles.begin(), circles.end(),
//             [](const Vec3f& a, const Vec3f& b) { return a[2] < b[2]; });
//
//        // 处理检测到的圆
//        vector<pair<Vec3f, Vec3f>> ringPairs;  // 存储内外圆对
//        for (size_t i = 0; i < circles.size(); i++) {
//            for (size_t j = i + 1; j < circles.size(); j++) {
//                Point2f center1(circles[i][0], circles[i][1]);
//                Point2f center2(circles[j][0], circles[j][1]);
//                float distance = norm(center1 - center2);
//
//                // 如果两个圆的圆心距离小于较小圆半径的一定比例，认为它们是同一个色环的内外圆
//                if (distance < circles[i][2] * 0.3) {
//                    ringPairs.push_back({circles[i], circles[j]});
//                    break;
//                }
//            }
//        }
//
//        // 绘制结果
//        Mat result = frame.clone();
//        for (const auto& pair : ringPairs) {
//            // 计算色环中心（内外圆的中点）
//            Point2f center((pair.first[0] + pair.second[0]) / 2,
//                           (pair.first[1] + pair.second[1]) / 2);
//
//            // 绘制内圆和外圆
//            circle(result, Point(pair.first[0], pair.first[1]), pair.first[2], Scalar(0, 255, 0), 2);
//            circle(result, Point(pair.second[0], pair.second[1]), pair.second[2], Scalar(0, 255, 0), 2);
//
//            // 绘制中心点
//            circle(result, center, 3, Scalar(0, 0, 255), -1);
//
//            // 计算并显示相对坐标
//            Point2f relativePos = center - imageCenter;
//            putText(result,
//                    "(" + to_string(int(relativePos.x)) + "," + to_string(int(relativePos.y)) + ")",
//                    Point(center.x + 10, center.y),
//                    FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 255, 0), 1);
//
//            cout << "色环中心相对坐标: ("
//                 << relativePos.x << ", " << relativePos.y << ")" << endl;
//        }
//
//        // 显示处理过程和结果
//        imshow("Edges", edges);
//        imshow("Morphology", morphology);
//        imshow("Result", result);
//    }
//};
//
//// 初始化静态成员变量
//int RingDetector::Parameters::cannyThreshold1 = 50;
//int RingDetector::Parameters::cannyThreshold2 = 150;
//int RingDetector::Parameters::minRadius = 20;
//int RingDetector::Parameters::maxRadius = 100;
//int RingDetector::Parameters::dilateSize = 3;
//int RingDetector::Parameters::erodeSize = 3;
//int RingDetector::Parameters::blurSize = 3;
//int RingDetector::Parameters::houghThreshold = 30;
//
//int main() {
//    RingDetector detector;
//    return 0;
//}
