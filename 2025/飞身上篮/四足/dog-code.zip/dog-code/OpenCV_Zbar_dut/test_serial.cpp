#include "SerialPort.hpp"
#include <array>
#include <chrono>
#include <iostream>
#include <ratio>
#include <thread>
#include <utility>
#include <vector>

void testSendArray() {
    std::cout << "测试发送任务数组..." << std::endl;

    try {
        SerialPort serial("/dev/ttyUSB0",
                          B115200); // 使用USB转串口，波特率115200
        if (!serial.isOpen()) {
            std::cout << "串口打开失败！" << std::endl;
            return;
        }

        // 测试数据
        std::array<int, 7> testArray1 = {1, 2, 3, 4, 5, 6, 1};
        std::array<int, 7> testArray2 = {6, 5, 4, 3, 2, 1, 1};

        bool send = false;
        int i = 0;
        while (1) {
            if (i % 2) {
                send = serial.sendArray(testArray1);
            } else {
                send = serial.sendArray(testArray2);
            }
            if (send) {
                std::cout << "成功发送数组: ";
                if (i % 2) {
                    for (int val: testArray1) {
                        std::cout << val << " ";
                    }
                } else {
                    for (int val: testArray2) {
                        std::cout << val << " ";
                    }
                }
            
                std::cout << std::endl;
            } else {
                std::cout << "发送失败！" << std::endl;
            }

            // 等待接收数据
            int received = serial.receiveData();
            if (received != -1) {
                std::cout << "收到数据: " << received << std::endl;
            }

            i++;
            // std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }

    } catch (std::exception const &e) {
        std::cout << "错误: " << e.what() << std::endl;
    }
}

void testSendCoordinates() {
    std::cout << "\n测试发送坐标..." << std::endl;

    try {
        SerialPort serial("/dev/ttyUSB0", B115200);
        if (!serial.isOpen()) {
            std::cout << "串口打开失败！" << std::endl;
            return;
        }

        // 测试不同坐标
        std::vector<std::pair<float, float>> testCoords = {{100.5, 200.79},
                                                           {-50.13, 75.8},
                                                           {0.0, 0.0},
                                                           {-150.2, -200.4},
                                                           {25.61, -35.9}};

        std::vector<float> test1 = {100.5, 200.79};
        std::vector<float> test2 = {-50.13, 75.8};
        int i = 0;
        bool send = false;

        while (1) {
            if (i % 2) {
                send = serial.sendCoordinates(test1[0], test1[1]);
            } else {
                send = serial.sendCoordinates(test2[0], test2[1]);
            }
            if (send) {
                if (i % 2) {
                    std::cout << "成功发送坐标: (" << test1[0] << ", "
                              << test1[1]<< ")" << std::endl;
                } else {
                    std::cout << "成功发送坐标: (" << test2[0] << ", "
                              << test2[1] << ")" << std::endl;
                }
            } else {
                std::cout << "发送失败！" << std::endl;
            }
            i++;
        }

    } catch (std::exception const &e) {
        std::cout << "错误: " << e.what() << std::endl;
    }
}

void testContinuousReceive() {
    std::cout << "\n测试持续接收..." << std::endl;

    try {
        SerialPort serial("/dev/ttyUSB0", B115200);
        if (!serial.isOpen()) {
            std::cout << "串口打开失败！" << std::endl;
            return;
        }

        std::cout << "开始接收数据（按Ctrl+C退出）..." << std::endl;

        // 持续接收10秒
        auto start = std::chrono::steady_clock::now();
        while (std::chrono::steady_clock::now() - start <
               std::chrono::seconds(10)) {
            int received = serial.receiveData();
            if (received != -1) {
                std::cout << "收到数据: " << received << std::endl;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

    } catch (std::exception const &e) {
        std::cout << "错误: " << e.what() << std::endl;
    }
}

int main() {
    std::cout << "串口通信测试程序\n" << std::endl;

    // 测试发送任务数组
    testSendArray();

    // // 测试发送坐标
    // testSendCoordinates();
    //
    // // 测试持续接收
//     testContinuousReceive();

    return 0;
}
