#include "RingDetector.hpp"
#include <iostream>
#include <opencv2/core/types.hpp>
#include <vector>

// 初始化静态成员变量
int RingDetector::Parameters::cannyThreshold1 = 50;
int RingDetector::Parameters::cannyThreshold2 = 150;
int RingDetector::Parameters::minRadius = 50;
int RingDetector::Parameters::maxRadius = 150;
int RingDetector::Parameters::minDist = 50;
int RingDetector::Parameters::dilateSize = 6;
int RingDetector::Parameters::erodeSize = 10;
int RingDetector::Parameters::blurSize = 5;
int RingDetector::Parameters::claheClipLimit = 3;
int RingDetector::Parameters::edgeThreshold = 30;

RingDetector::RingDetector(cv::VideoCapture &camera) : cap(camera) {
    //    cap.open(4, cv::CAP_V4L2);
    //    if (!cap.isOpened()) {
    //        throw std::runtime_error("无法打开摄像头");
    //    }

    cap.read(frame);
    imageCenter = cv::Point2f(frame.cols / 2.0f, frame.rows / 2.0f);

    cv::namedWindow("Parameters");
    createTrackbars();
}

RingDetector::~RingDetector() {
    cap.release();
    cv::destroyAllWindows();
}

void RingDetector::createTrackbars() {
    cv::createTrackbar("Canny Threshold1", "Parameters",
                       &params.cannyThreshold1, 255);
    cv::createTrackbar("Canny Threshold2", "Parameters",
                       &params.cannyThreshold2, 255);
    cv::createTrackbar("Min Radius", "Parameters", &params.minRadius, 100);
    cv::createTrackbar("Max Radius", "Parameters", &params.maxRadius, 200);
    cv::createTrackbar("Min Distance", "Parameters", &params.minDist, 200);
    cv::createTrackbar("Dilate Size", "Parameters", &params.dilateSize, 20);
    cv::createTrackbar("Erode Size", "Parameters", &params.erodeSize, 20);
    cv::createTrackbar("Blur Size", "Parameters", &params.blurSize, 20);
    cv::createTrackbar("CLAHE Clip Limit", "Parameters",
    &params.claheClipLimit,
                       10);
    cv::createTrackbar("Edge Threshold", "Parameters", &params.edgeThreshold,
                       255);
}

std::optional<cv::Point2f> RingDetector::processFrame() {
    cap.read(frame);
    if (frame.empty()) {
        return std::nullopt;
    }

    // std::optional<cv::Point2f> result = std::nullopt;
    cv::Point2f result = cv::Point2f(0, 0);
    std::vector<cv::Point2f> currentCenters;

    // 1. 自适应直方图均衡化预处理
    cv::Mat lab;
    cv::cvtColor(frame, lab, cv::COLOR_BGR2Lab);
    std::vector<cv::Mat> lab_planes(3);
    cv::split(lab, lab_planes);
    cv::Ptr<cv::CLAHE> clahe =
        cv::createCLAHE(params.claheClipLimit, cv::Size(8, 8));
    cv::Mat dst;
    clahe->apply(lab_planes[0], dst);
    dst.copyTo(lab_planes[0]);
    cv::merge(lab_planes, lab);
    cv::cvtColor(lab, frame, cv::COLOR_Lab2BGR);

    // 2. 转换为灰度图
    cv::Mat gray;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);

    // 3. 使用双边滤波
    cv::Mat blurred;
    cv::bilateralFilter(gray, blurred, -1, 50, 5);

    // 4. 自适应阈值分割
    cv::Mat binary;
    cv::adaptiveThreshold(blurred, binary, 255,
    cv::ADAPTIVE_THRESH_GAUSSIAN_C,
                          cv::THRESH_BINARY, 2 * params.blurSize + 1, 2);

    // 5. 多尺度Canny边缘检测
    cv::Mat edges;
    std::vector<cv::Mat> edgesList;
    for (int i = -10; i <= 10; i += 10) {
        cv::Mat edge;
        cv::Canny(blurred, edge, std::max(0, params.cannyThreshold1 + i),
                  std::max(0, params.cannyThreshold2 + i));
        edgesList.push_back(edge);
    }

    edges = edgesList[0];
    for (size_t i = 1; i < edgesList.size(); i++) {
        cv::bitwise_or(edges, edgesList[i], edges);
    }

    // 6. 形态学操作
    cv::Mat morphology = edges.clone();

    int dilateSize = params.dilateSize * 2 + 1;
    cv::Mat dilateElement = cv::getStructuringElement(
        cv::MORPH_ELLIPSE, cv::Size(dilateSize, dilateSize));
    cv::dilate(morphology, morphology, dilateElement);

    int erodeSize = params.erodeSize * 2 + 1;
    cv::Mat erodeElement = cv::getStructuringElement(
        cv::MORPH_ELLIPSE, cv::Size(erodeSize, erodeSize));
    cv::erode(morphology, morphology, erodeElement);

    // 7. 轮廓检测
    std::vector<std::vector<cv::Point>> contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::findContours(morphology, contours, hierarchy, cv::RETR_EXTERNAL,
                     cv::CHAIN_APPROX_SIMPLE);

    for (const auto &contour : contours) {
        double area = cv::contourArea(contour);
        if (area < 500)
            continue;

        // 8. 圆形度计算
        double perimeter = cv::arcLength(contour, true);
        double circularity = 4 * CV_PI * area / (perimeter * perimeter);

        if (circularity < 0.3)
            continue;

        // 9. 椭圆拟合
        if (contour.size() > 5) {
            cv::RotatedRect ellipse = cv::fitEllipse(contour);
            float ratio = std::min(ellipse.size.width, ellipse.size.height) /
                          std::max(ellipse.size.width, ellipse.size.height);
            if (ratio < 0.7)
                continue;
        }

        cv::Point2f center;
        float radius;
        cv::minEnclosingCircle(contour, center, radius);

        if (radius < params.minRadius || radius > params.maxRadius)
            continue;

        // 10. 验证边缘强度
        float avgEdgeStrength = 0;
        int count = 0;
        for (int angle = 0; angle < 360; angle += 10) {
            float radian = angle * CV_PI / 180.0;
            cv::Point2f edgePoint(center.x + radius * std::cos(radian),
                                  center.y + radius * std::sin(radian));

            if (edgePoint.x >= 0 && edgePoint.x < edges.cols &&
                edgePoint.y >= 0 && edgePoint.y < edges.rows) {
                avgEdgeStrength += edges.at<uchar>(edgePoint.y, edgePoint.x);
                count++;
            }
        }
        avgEdgeStrength /= count;
        if (avgEdgeStrength < params.edgeThreshold)
            continue;

        // 11. 时间平滑
        cv::Point2f smoothedCenter = center;
        if (!lastCenters.empty()) {
            float minDist = FLT_MAX;
            cv::Point2f *nearestCenter = nullptr;
            for (auto &lastCenter : lastCenters) {
                float dist = cv::norm(center - lastCenter);
                if (dist < minDist) {
                    minDist = dist;
                    nearestCenter = &lastCenter;
                }
            }

            if (nearestCenter && minDist < 50) {
                smoothedCenter = *nearestCenter * 0.3f + center * 0.7f;
            }
        }

        // 计算相对位置并更新返回值
        cv::Point2f relativePos = smoothedCenter - imageCenter;
        // std::cout << "smoothedCenter.x: " << smoothedCenter.x <<std::endl;
        // std::cout << "smoothedCenter.y: " << smoothedCenter.y <<std::endl;
        // std::cout << "imageCenter.x: " << imageCenter.x << std::endl;
        // std::cout << "imageCenter.y: " << imageCenter.y << std::endl;

        float physicalRadius = 105.0f; // 实际色环半径(mm)
        float distanceScale = physicalRadius / (radius * 2);
        // std::cout << "relativePos.x: " << relativePos.x << std::endl;
        // std::cout << "relativePos.y: " << relativePos.y << std::endl;
        //
        // std::cout << "radius: " << radius << std::endl;

        float realx = relativePos.x * distanceScale;
        float realy = relativePos.y * distanceScale;

        if (realx > 70 || realy > 70 || realx < -70 || realy < -70) {
            continue;
            // result = cv::Point2f(0, 0);
        }
        // 更新返回值
        result = cv::Point2f(realx+4, realy+51);

        // 可视化
        cv::circle(frame, smoothedCenter, radius, cv::Scalar(0, 255, 0), 2);
        cv::circle(frame, smoothedCenter, 3, cv::Scalar(0, 0, 255), -1);

        cv::putText(frame,
                    "(" + std::to_string(int(result.x)) + "," +
                        std::to_string(int(result.y)) + ")",
                    cv::Point(smoothedCenter.x + 10, smoothedCenter.y),
                    cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 0), 1);

        currentCenters.push_back(smoothedCenter);
    }

    // 更新历史中心点
    lastCenters = currentCenters;

    // 显示结果
    showResults();
    cv::imshow("Binary", binary);
    cv::imshow("Edges", edges);
    cv::imshow("Morphology", morphology);

    return result;
}

void RingDetector::showResults() {
    // 绘制图像中心十字线
    cv::line(frame, cv::Point(imageCenter.x - 10, imageCenter.y),
             cv::Point(imageCenter.x + 10, imageCenter.y),
             cv::Scalar(0, 0, 255), 2);
    cv::line(frame, cv::Point(imageCenter.x, imageCenter.y - 10),
             cv::Point(imageCenter.x, imageCenter.y + 10),
             cv::Scalar(0, 0, 255), 2);

    cv::imshow("Ring Detection", frame);
}

