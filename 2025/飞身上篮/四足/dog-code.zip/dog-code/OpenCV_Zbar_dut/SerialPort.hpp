#pragma once
#include <array>
#include <string>
#include <termios.h>

class SerialPort {
public:
  SerialPort(const std::string &port = "/dev/ttyUSB0", int baudrate = B115200);
  ~SerialPort();

  bool isOpen() const { return fd >= 0; }
  bool sendArray(const std::array<int, 9> &data);
  bool sendCoordinates(float x, float y);
  int receiveData();

private:
  int fd;
  void configurePort(int baudrate);
};
