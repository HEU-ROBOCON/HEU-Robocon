#pragma once
#include "RingDetector.hpp"
#include "SerialPort.hpp"
#include <array>
#include <memory>
#include <opencv2/opencv.hpp>
#include <string>
#include <zbar.h>

class TaskManager {
public:
  TaskManager();
  ~TaskManager();
  void run();

private:
  // 任务数组：前6位为任务码，第7位为当前检测到的颜色
  std::array<int, 7> taskArray;
  bool qrCodeDetected = false;

  // 摄像头
  cv::VideoCapture cap1; // 二维码摄像头
  cv::VideoCapture cap2; // 颜色检测摄像头

  cv::VideoCapture &getActiveCamera() { return cap2; } // 用于共享摄像头

  // ZBar扫描器
  std::unique_ptr<zbar::ImageScanner> scanner;

  // 颜色检测相关
  cv::Point2f imageCenter;
  cv::Rect centerROI;

  struct ColorRange {
    cv::Scalar lower;
    cv::Scalar upper;
    std::string name;
    cv::Scalar color;
  };

  std::vector<ColorRange> colorRanges;

  std::unique_ptr<SerialPort> serial;
  std::unique_ptr<RingDetector> ringDetector;
  bool detectingRing = false;

  // 初始化函数
  void initCameras();
  void initScanner();
  void initColorRanges();

  // 处理函数
  void processQRCode();
  int processColor();

  // 辅助函数
  void parseQRCode(std::string const &qrData);
  void displayResults();
};
