#include "SerialPort.hpp"
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <iostream>
#include <ostream>
#include <unistd.h>

SerialPort::SerialPort(std::string const &port, int baudrate) {
  fd = open(port.c_str(), O_RDWR | O_NOCTTY);
  if (fd < 0) {
    std::cerr << "Error opening serial port" << std::endl;
    return;
  }
  configurePort(baudrate);
}

SerialPort::~SerialPort() {
  if (fd >= 0) {
    close(fd);
  }
}

void SerialPort::configurePort(int baudrate) {
  struct termios tty;
  memset(&tty, 0, sizeof(tty));

  if (tcgetattr(fd, &tty) != 0) {
    std::cerr << "Error from tcgetattr" << std::endl;
    return;
  }

  cfsetospeed(&tty, baudrate);
  cfsetispeed(&tty, baudrate);

  tty.c_cflag |= (CLOCAL | CREAD); /* ignore modem controls */
  tty.c_cflag &= ~CSIZE;
  tty.c_cflag |= CS8;      /* 8-bit characters */
  tty.c_cflag &= ~PARENB;  /* no parity bit */
  tty.c_cflag &= ~CSTOPB;  /* only need 1 stop bit */
  tty.c_cflag &= ~CRTSCTS; /* no hardware flowcontrol */

  tty.c_lflag &= ~ICANON;
  tty.c_lflag &= ~ECHO;
  tty.c_lflag &= ~ECHOE;
  tty.c_lflag &= ~ECHONL;
  tty.c_lflag &= ~ISIG;

  tty.c_iflag &= ~(IXON | IXOFF | IXANY);
  tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL);

  tty.c_oflag &= ~OPOST;
  tty.c_oflag &= ~ONLCR;

  tty.c_cc[VMIN] = 0;
  tty.c_cc[VTIME] = 0;

  if (tcsetattr(fd, TCSANOW, &tty) != 0) {
    std::cerr << "Error from tcsetattr" << std::endl;
  }
  // 设置非阻塞模式
  int flags = fcntl(fd, F_GETFL, 0);
  fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

// bool SerialPort::sendArray(const std::array<int, 7>& data) {
//     std::string msg;
//     // msg = "0A";
//     for (int val : data) {
//         msg += std::to_string(val);
//     }
//     // msg += "0D";
//     return write(fd, msg.c_str(), msg.length()) ==
//     static_cast<ssize_t>(msg.length());
// }
//
// bool SerialPort::sendCoordinates(float x, float y) {
//     std::string msg = std::to_string(x)  + std::to_string(y);
//     return write(fd, msg.c_str(), msg.length()) ==
//     static_cast<ssize_t>(msg.length());
// }
//
// int SerialPort::receiveData() {
//     char buffer[2];
//     if (read(fd, buffer, 1) > 0) {
//         return buffer[0] - '0';
//     }
//     return -1;
// }

struct DataPacket {
  uint8_t header[2] = {0x0A, 0x0D};
  // uint8_t data[28];
  uint8_t data[8];
  uint8_t tail[2] = {0x0B, 0x0C};
};

bool SerialPort::sendArray(std::array<int, 7> const &data) {
  DataPacket packet;

  // // 将整数数组转换为字节数组
  // for(int i = 0; i < 7; i++) {
  //     packet.data[i * 4] = (data[i] >> 24) & 0xFF;
  //     packet.data[i * 4 + 1] = (data[i] >> 16) & 0xFF;
  //     packet.data[i * 4 + 2] = (data[i] >> 8) & 0xFF;
  //     packet.data[i * 4 + 3] = data[i] & 0xFF;
  // }
  for (int i = 0; i < 7; i++) {
    packet.data[i] = static_cast<uint8_t>(data[i]);
  }

  packet.data[7] = static_cast<uint8_t>(0);
  size_t totalSize = sizeof(DataPacket);
  // std::cout<< "size : "<<totalSize<<std::endl;
  return write(fd, &packet, totalSize) == static_cast<ssize_t>(totalSize);
}

bool SerialPort::sendCoordinates(float x, float y) {
  DataPacket packet;

  uint8_t *x_bytes = reinterpret_cast<uint8_t *>(&x);
  uint8_t *y_bytes = reinterpret_cast<uint8_t *>(&y);

  // 复制x坐标的4个字节
  for (int i = 0; i < 4; i++) {
    packet.data[i] = x_bytes[i];
  }

  for (int i = 0; i < 4; i++) {
    packet.data[i + 4] = y_bytes[i];
  }

  size_t totalSize = sizeof(packet.header) + 8 + sizeof(packet.tail);

  // std::cout<< "size : "<<totalSize<<std::endl;
  return write(fd, &packet, totalSize) == static_cast<ssize_t>(totalSize);
}

int SerialPort::receiveData() {
  uint8_t buffer[32];
  uint8_t header[2] = {0x0A, 0x0D};

  // 查找帧头
  while (true) {
    if (read(fd, buffer, 1) > 0) {
      if (buffer[0] == header[0]) {
        if (read(fd, buffer + 1, 1) > 0 && buffer[1] == header[1]) {
          // 找到帧头，读取数据
          if (read(fd, buffer + 2, 1) > 0) {
            std::cout << "recive:" << buffer[2] << std::endl;
            return buffer[2]; // 返回数据
          }
        }
      }
    }
    return -1;
  }
}
