#include "TaskManager.hpp"
#include <iostream>
#include <ostream>

TaskManager::TaskManager() {
    taskArray.fill(0); // 初始化任务数组为0
    initCameras();
    initScanner();
    initColorRanges();
}

TaskManager::~TaskManager() {
    cap1.release();
    cap2.release();
    cv::destroyAllWindows();
}

void TaskManager::initCameras() {
    cap1.open(0, cv::CAP_V4L2); // 二维码摄像头
    cap2.open(2, cv::CAP_V4L2); // 颜色检测摄像头

    if (!cap1.isOpened() || !cap2.isOpened()) {
        throw std::runtime_error("无法打开摄像头");
    }

    // 初始化颜色检测相关参数
    cv::Mat frame;
    cap2.read(frame);
    imageCenter = cv::Point2f(frame.cols / 2.0f, frame.rows / 2.0f);
    int roiSize = std::min(frame.cols, frame.rows) / 4;
    centerROI = cv::Rect(imageCenter.x - roiSize / 2,
                         imageCenter.y - roiSize / 2, roiSize, roiSize);
}

void TaskManager::initScanner() {
    scanner = std::make_unique<zbar::ImageScanner>();
    scanner->set_config(zbar::ZBAR_NONE, zbar::ZBAR_CFG_ENABLE, 1);
}

void TaskManager::initColorRanges() {
    colorRanges = {
        {{0, 70, 50}, {10, 255, 255}, "red", cv::Scalar(0, 0, 255)},
        {{170, 70, 50}, {180, 255, 255}, "red", cv::Scalar(0, 0, 255)},
        {{35, 70, 50}, {85, 255, 255}, "green", cv::Scalar(0, 255, 0)},
        {{100, 70, 50}, {130, 255, 255}, "blue", cv::Scalar(255, 0, 0)}};
}

void testSendArray() {
    std::cout << "测试发送任务数组..." << std::endl;

    try {
        SerialPort serial("/dev/ttyUSB0",
                          B115200); // 使用USB转串口，波特率115200
        if (!serial.isOpen()) {
            std::cout << "串口打开失败！" << std::endl;
            return;
        }

        // 测试数据
        std::array<int, 7> testArray1 = {1, 2, 3, 4, 5, 6, 1};
        std::array<int, 7> testArray2 = {6, 5, 4, 3, 2, 1, 1};

        bool send = false;
        int i = 0;
        while (1) {
            if (i % 2) {
                send = serial.sendArray(testArray1);
            } else {
                send = serial.sendArray(testArray2);
            }
            if (send) {
                std::cout << "成功发送数组: ";
                if (i % 2) {
                    for (int val : testArray1) {
                        std::cout << val << " ";
                    }
                } else {
                    for (int val : testArray2) {
                        std::cout << val << " ";
                    }
                }

                std::cout << std::endl;
            } else {
                std::cout << "发送失败！" << std::endl;
            }

            // 等待接收数据
            int received = serial.receiveData();
            if (received != -1) {
                std::cout << "收到数据: " << received << std::endl;
            }

            i++;
            // std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }

    } catch (std::exception const &e) {
        std::cout << "错误: " << e.what() << std::endl;
    }
}

void TaskManager::run() {

    SerialPort serial("/dev/ttyUSB0",
                      B115200); // 使用USB转串口，波特率115200
    if (!serial.isOpen()) {
        std::cout << "串口打开失败！" << std::endl;
        return;
    }
    while (true) {


        if (!detectingRing) {
            // 处理二维码和颜色检测
            if (!qrCodeDetected) {
                processQRCode();
            }

            int colorCode = processColor();
            taskArray[6] = colorCode;

            // 发送任务数组到STM32
            serial.sendArray(taskArray);
            int received = serial.receiveData();
            // 检查是否收到切换信号
            if (received == 1) {
                detectingRing = true;
                ringDetector =
                    std::make_unique<RingDetector>(getActiveCamera());
            }
            if (received == 3) {
                detectingRing = true;
            }
        } else {
            // 色环检测和定位
            auto coordinates = ringDetector->processFrame();
            if (coordinates.has_value()) {
                serial.sendCoordinates(coordinates->x, coordinates->y);
                int received = serial.receiveData();
                if (received == 2) {
                    detectingRing = false;
                }

                std::cout << "( " << coordinates->x << " ," << coordinates->y
                          << std::endl;
            }
        }

        if (cv::waitKey(1) == 'q') {
            break;
        }
    }
}

//void TaskManager::run() {
//
//    ringDetector = std::make_unique<RingDetector>(getActiveCamera());
//
//    while (true) {
//        auto coordinates = ringDetector->processFrame();
//        if (coordinates.has_value()) {
//            std::cout << coordinates->x << " , " << coordinates->y <<
//            std::endl;
//        }
//
//        displayResults();
//        if (cv::waitKey(1) == 'q') {
//            break;
//        }
//    }
//}

// void TaskManager::processQRCode() {
//     std::cout << "二维码来了" << std::endl;
//     cv::Mat frame;
//     cap1 >> frame;
//     if (frame.empty()) {
//         return;
//     }
//
//     cv::Mat gray;
//     cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
//
//     zbar::Image image(gray.cols, gray.rows, "Y800", gray.data,
//                       gray.cols * gray.rows);
//
//     if (scanner->scan(image) > 0) {
//         for (auto symbol = image.symbol_begin(); symbol !=
//         image.symbol_end();
//              ++symbol) {
//             std::string qrData = symbol->get_data();
//             std::cout << "----------" << std::endl;
//             parseQRCode(qrData);
//
//             qrCodeDetected = true;
//
//             // 在图像上显示二维码位置
//             std::vector<cv::Point> points;
//             for (int i = 0; i < symbol->get_location_size(); i++) {
//                 points.push_back(cv::Point(symbol->get_location_x(i),
//                                            symbol->get_location_y(i)));
//             }
//             cv::polylines(frame, points, true, cv::Scalar(0, 255, 0), 2);
//         }
//     }
//
//     cv::imshow("QR Code", frame);
// }


void TaskManager::processQRCode() {
    std::cout << "正在处理二维码..." << std::endl;

    // 确保窗口创建
    cv::namedWindow("QR Code", cv::WINDOW_AUTOSIZE);

    cv::Mat frame;
    cap1 >> frame;
    if (frame.empty()) {
        std::cout << "无法获取摄像头图像" << std::endl;
        return;
    }

    // 显示原始图像尺寸
    std::cout << "图像尺寸: " << frame.size() << std::endl;

    cv::Mat gray;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);

    // 检查灰度图转换是否成功
    if (gray.empty()) {
        std::cout << "灰度图转换失败" << std::endl;
        return;
    }

    // 创建zbar图像
    zbar::Image image(gray.cols, gray.rows, "Y800", gray.data,
                      gray.cols * gray.rows);

    // 扫描二维码
    int result = scanner->scan(image);
    std::cout << "扫描结果: " << result << std::endl;

    if (result > 0) {
        for (auto symbol = image.symbol_begin(); symbol != image.symbol_end();
             ++symbol) {
            std::string qrData = symbol->get_data();
            std::cout << "识别到二维码数据: " << qrData << std::endl;

            parseQRCode(qrData);
            qrCodeDetected = true;

            // 在图像上显示二维码位置
            std::vector<cv::Point> points;
            for (int i = 0; i < symbol->get_location_size(); i++) {
                points.push_back(cv::Point(symbol->get_location_x(i),
                                           symbol->get_location_y(i)));
            }

            // 绘制二维码边框
            cv::polylines(frame, points, true, cv::Scalar(0, 255, 0), 2);

            // 显示二维码内容
            cv::putText(frame, qrData, points[0], cv::FONT_HERSHEY_SIMPLEX, 1.0,
                        cv::Scalar(0, 255, 0), 2);
        }
    }

    // 显示图像
    cv::imshow("QR Code", frame);
    cv::waitKey(1); // 给窗口更新一个短暂的延时
}

void TaskManager::parseQRCode(std::string const &qrData) {
    if (qrData.length() == 7 && qrData[3] == '+') {
        for (int i = 0; i < 3; i++) {
            taskArray[i] = qrData[i] - '0';
            taskArray[i + 3] = qrData[i + 4] - '0';
        }
    }
}

int TaskManager::processColor() {
    cv::Mat frame;
    cap2 >> frame;
    if (frame.empty()) {
        return 0;
    }

    // 自适应直方图均衡化
    cv::Mat lab;
    cvtColor(frame, lab, cv::COLOR_BGR2Lab);
    std::vector<cv::Mat> lab_planes(3);
    split(lab, lab_planes);
    cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE(2.0, cv::Size(8, 8));
    cv::Mat dst;
    clahe->apply(lab_planes[0], dst);
    dst.copyTo(lab_planes[0]);
    merge(lab_planes, lab);
    cvtColor(lab, frame, cv::COLOR_Lab2BGR);

    // 高斯模糊
    cv::Mat blurred;
    GaussianBlur(frame, blurred, cv::Size(7, 7), 0);

    // 转换到HSV颜色空间
    cv::Mat hsv;
    cvtColor(blurred, hsv, cv::COLOR_BGR2HSV);

    int colorCode = 0;    // 默认为0，表示没有检测到颜色
    float maxRatio = 0.2; // 颜色检测阈值

    // 处理每种颜色
    for (auto const &range : colorRanges) {
        // 颜色分割
        cv::Mat mask;
        inRange(hsv, range.lower, range.upper, mask);

        // 形态学操作
        cv::Mat kernel =
            getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(7, 7));
        morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
        morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);

        // 中值滤波去除噪点
        medianBlur(mask, mask, 5);

        // 计算ROI区域内的颜色占比
        cv::Mat roiMask = mask(centerROI);
        int colorPixels = countNonZero(roiMask);
        float colorRatio =
            (float)colorPixels / (centerROI.width * centerROI.height);

        // 更新颜色代码
        if (colorRatio > maxRatio) {
            if (range.name == "red") {
                colorCode = 1;
                putText(frame, "RED", cv::Point(centerROI.x, centerROI.y - 10),
                        cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 255),
                        2);
            } else if (range.name == "green") {
                colorCode = 2;
                putText(
                    frame, "GREEN",
                    cv::Point(centerROI.x, centerROI.y + centerROI.height + 25),
                    cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 255, 0), 2);
            } else if (range.name == "blue") {
                colorCode = 3;
                putText(frame, "BLUE",
                        cv::Point(centerROI.x + centerROI.width + 10,
                                  centerROI.y + centerROI.height / 2),
                        cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255, 0, 0),
                        2);
            }
        }

        // 显示颜色掩码
        std::string windowName = "Mask " + range.name;
        putText(mask, "Ratio: " + std::to_string(colorRatio).substr(0, 4),
                cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(255), 1);
        cv::imshow(windowName, mask);
    }

    // 绘制中心矩形区域
    rectangle(frame, centerROI, cv::Scalar(0, 255, 255), 2);

    // 显示颜色代码状态
    std::string status = "Color Code: " + std::to_string(colorCode);
    putText(frame, status, cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.7,
            cv::Scalar(0, 255, 255), 2);

    // 显示结果
    cv::imshow("Color Detection", frame);

    return colorCode;
}

void TaskManager::displayResults() {
    // std::cout << "Task Array: ";
    // for (int i = 0; i < 7; i++) {
    //   std::cout << taskArray[i] << " ";
    // }
    // std::cout << std::endl;
}
