#include <cstdint>
#include <fast_lio/AprilTagDetectionArray.h>
#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <serial/serial.h>
#include <string>
#include <tf/tf.h>
#include <vector>

#pragma pack(1) // 1字节对齐
struct CombinedData {
    uint8_t header[2] = {0x0A, 0x0B}; // 包头
    uint8_t id;
    float x;     // 位置x (厘米)
    float y;     // 位置y (厘米)
    float z;     // 位置z (厘米)
    float roll;  // 姿态roll (度)
    float pitch; // 姿态pitch (度)
    float yaw;   // 姿态yaw (度)

    float x_a;                      // 位置x (厘米)
    float y_a;                      // 位置x (厘米)
    float z_a;                      // 位置x (厘米)
    float roll_a;                   // 姿态roll (度)
    float pitch_a;                  // 姿态pitch (度)
    float yaw_a;                    // 姿态yaw (度)
    uint8_t tail[2] = {0x0C, 0x0D}; // 包尾
} combined_data;
#pragma pack()

serial::Serial ser; // 串口对象

std::string g_port;
int g_baudrate;

// 全局变量存储最新的数据
float latest_id = 0, latest_x = 0, latest_y = 0, latest_z = 0 ,latest_roll = 0,latest_pitch = 0,latest_yaw = 0;
float latest_x_a = 0, latest_y_a = 0, latest_z_a = 0, latest_roll_a = 0,
      latest_pitch_a = 0, latest_yaw_a = 0;
double roll_cam, pitch_cam, yaw_cam;
tf::Vector3 p_cam_in_tag;

void odomCallback(const nav_msgs::Odometry::ConstPtr &msg) {
    // 更新位置数据（转换为厘米）
    latest_x = msg->pose.pose.position.x * 100.0;
    latest_y = msg->pose.pose.position.y * 100.0;
    latest_z = msg->pose.pose.position.z * 100.0;
    double qx = msg->pose.pose.orientation.x;
    double qy = msg->pose.pose.orientation.y;
    double qz = msg->pose.pose.orientation.z;
    double qw = msg->pose.pose.orientation.w;

    tf::Quaternion q(qx, qy, qz, qw);
    tf::Matrix3x3 m(q);
    double roll, pitch, yaw;
    m.getRPY(roll, pitch, yaw);

    // 转换为角度并存储
    latest_roll = roll * 180.0 / M_PI;
    latest_pitch = pitch * 180.0 / M_PI;
    latest_yaw = yaw * 180.0 / M_PI;
}

void apriltagCallback(const fast_lio::AprilTagDetectionArray::ConstPtr &msg) {
    if (msg->detections.empty()) {
        // 没有检测到AprilTag，设置默认姿态
        latest_id = 0;
        latest_x_a = 0;
        latest_y_a = 0;
        latest_z_a = 0;
        latest_roll_a = 0;
        latest_pitch_a = 0;
        latest_yaw_a = 0;
    } else {

        size_t min_idx = 0;
        double min_dist = std::numeric_limits<double>::max();
        for (size_t i = 0; i < msg->detections.size(); ++i) {
            double z = msg->detections[i].pose.position.z;
            if (z < min_dist) {
                min_dist = z;
                min_idx = i;
            }
        }
        const fast_lio::AprilTagDetection &detection = msg->detections[min_idx];
        // const fast_lio::AprilTagDetection &detection = msg->detections[0];

        // 将四元数转换为欧拉角
        double qx = detection.pose.orientation.x;
        double qy = detection.pose.orientation.y;
        double qz = detection.pose.orientation.z;
        double qw = detection.pose.orientation.w;

        // 计算欧拉角
        double roll, pitch, yaw;

        // 四元数转欧拉角
        double sinr_cosp = 2 * (qw * qx + qy * qz);
        double cosr_cosp = 1 - 2 * (qx * qx + qy * qy);
        roll = std::atan2(sinr_cosp, cosr_cosp);
        double sinp = 2 * (qw * qy - qz * qx);
          if (std::abs(sinp) >= 1) {
            pitch = std::copysign(M_PI / 2, sinp);
        } else {
            pitch = std::asin(sinp);
        }

        double siny_cosp = 2 * (qw * qz + qx * qy);
        double cosy_cosp = 1 - 2 * (qy * qy + qz * qz);
        yaw = std::atan2(siny_cosp, cosy_cosp);

        // 转换为角度
        latest_roll_a = roll * 180.0 / M_PI;
        latest_pitch_a = pitch * 180.0 / M_PI;
        latest_yaw_a = yaw * 180.0 / M_PI;
        latest_id = detection.id;
        latest_x_a = detection.pose.position.x * 100.0;
        latest_y_a = detection.pose.position.y * 100.0;
        latest_z_a = detection.pose.position.z * 100.0;
	tf::Quaternion q_tag_in_cam(qx, qy, qz, qw);
	tf::Matrix3x3 R_tag_in_cam(q_tag_in_cam);
	tf::Vector3 p_tag_in_cam(detection.pose.position.x,
	detection.pose.position.y,
	detection.pose.position.z);
	tf::Matrix3x3 R_cam_in_tag = R_tag_in_cam.transpose();
	p_cam_in_tag = R_cam_in_tag * (-p_tag_in_cam);
	//ROS_INFO("Camera in tag frame: x=%.3f, y=%.3f, z=%.3f (m)", p_cam_in_tag.x(), p_cam_in_tag.y(), p_cam_in_tag.z());
	
	tf::Quaternion q_cam_in_tag = q_tag_in_cam.inverse();
	
	tf::Matrix3x3(R_cam_in_tag).getRPY(roll_cam, pitch_cam, yaw_cam);
	//ROS_INFO("Camera in tag frame: roll=%.1f°, pitch=%.1f°, yaw=%.1f°", roll_cam * 180.0 / M_PI, pitch_cam * 180.0 / M_PI, yaw_cam * 180.0 / M_PI);
    }
}

bool reopenSerial() {
    try {
        if (ser.isOpen()) ser.close();
        ser.setPort(g_port);
        ser.setBaudrate(g_baudrate);
        serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(timeout);
        ser.open();
        if (ser.isOpen()) {
            ROS_WARN_STREAM("Serial port re-opened successfully!");
            return true;
        } else {
            ROS_ERROR_STREAM("Failed to re-open serial port " << g_port);
            return false;
        }
    } catch (serial::SerialException &e) {
        ROS_ERROR_STREAM("Serial re-open error: " << e.what());
        return false;
    } catch (serial::IOException &e) {
        ROS_ERROR_STREAM("Serial io re-open error: " << e.what());
        return false;
    }
}


void sendCombinedData() {
    // 填充数据结构
    combined_data.id = latest_id;
    combined_data.x = latest_x;
    combined_data.y = latest_y;
    combined_data.z = latest_z;
    combined_data.x_a = p_cam_in_tag.x() * 100.0;
    combined_data.y_a = p_cam_in_tag.y() * 100.;
    combined_data.z_a = p_cam_in_tag.z() * 100.;
    combined_data.roll_a = roll_cam * 180.0 / M_PI;
    combined_data.pitch_a = pitch_cam * 180.0 / M_PI;
    combined_data.yaw_a = yaw_cam * 180.0 / M_PI;
    combined_data.roll = latest_roll;
    combined_data.pitch = latest_pitch;
    combined_data.yaw = latest_yaw;

    if (!ser.isOpen()) {
        ROS_WARN_STREAM("Serial port not open, trying to reopen...");
        reopenSerial();
    }

    // 发送数据
    if (ser.isOpen()) {
        try {
            ser.write(reinterpret_cast<uint8_t *>(&combined_data),
                      sizeof(CombinedData));

            // 打印发送的数据（调试用）
            ROS_INFO("Sent combined data: id=%d, x=%.1fcm, y=%.1fcm, z=%.1fcm, roll=%.1f, pitch=%.1f, yaw=%.1f,"
                     "x_a=%.1fcm, y_a=%.1fcm, z_a=%.1fcm, roll_a=%.1f°, "
                     "pitch_a=%.1f°, yaw_a=%.1f°",
                     combined_data.id, combined_data.x, combined_data.y,
                     combined_data.z, combined_data.roll, combined_data.pitch,combined_data.yaw,combined_data.x_a, combined_data.y_a,
                     combined_data.z_a, combined_data.roll_a,
                     combined_data.pitch_a, combined_data.yaw_a);
            //std::cout<<"~~~ x_a_g = "<< latest_x_a_g<< ",z_a_g = "<<latest_z_a_g;  
        } catch (serial::SerialException &e) {
            ROS_ERROR_STREAM("Serial write error: " << e.what());
            reopenSerial();
        } catch (serial::IOException &e) {
            ROS_ERROR_STREAM("Serial io write error: " << e.what());
            reopenSerial();
        }
    }
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "combined_serial_sender");
    ros::NodeHandle nh;

    // 从参数服务器获取串口参数
    std::string port;
    int baudrate;
    nh.param<std::string>("serial_port", port, "/dev/ttyUSB0");
    nh.param<int>("baudrate", baudrate, 115200);

    g_port = port;
    g_baudrate = baudrate;

    try {
        // 配置串口
        ser.setPort(port);
        ser.setBaudrate(baudrate);
        serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(timeout);
        ser.open();
    } catch (serial::SerialException &e) {
        ROS_ERROR_STREAM("Unable to open serial port: " << e.what());
        return -1;
    }

    if (ser.isOpen()) {
        ROS_INFO_STREAM("Serial port " << port << " opened successfully");
    } else {
        ROS_ERROR_STREAM("Failed to open serial port " << port);
        return -1;
    }

    // 订阅位姿话题
    ros::Subscriber pose_sub = nh.subscribe("/Odometry", 20, odomCallback);

    // 订阅AprilTag检测话题
    ros::Subscriber apriltag_sub =
        nh.subscribe("/apriltag_detections", 20, apriltagCallback);

    ROS_INFO("开始通过串口发送合并数据（位置+姿态）...");

    // 设置定时器，定期发送数据
    ros::Timer timer =
        nh.createTimer(ros::Duration(0.05),
                       [](const ros::TimerEvent &) { sendCombinedData(); });

    ros::spin();

    // 关闭串口
    if (ser.isOpen()) {
        ser.close();
    }

    return 0;
}
