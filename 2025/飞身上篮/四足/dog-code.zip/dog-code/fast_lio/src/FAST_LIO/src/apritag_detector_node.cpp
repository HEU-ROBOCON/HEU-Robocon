#include <apriltag.h>
#include <apriltag_math.h>
#include <apriltag_pose.h>
#include <cmath>
#include <cv_bridge/cv_bridge.h>
#include <fast_lio/AprilTagDetection.h>
#include <fast_lio/AprilTagDetectionArray.h>
#include <geometry_msgs/PoseStamped.h>
#include <iomanip>
#include <iostream>
#include <librealsense2/rs.hpp>
#include <opencv2/opencv.hpp>
#include <ros/ros.h>
#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/Image.h>
#include <sstream>
#include <tag36h11.h>
#include <vector>

class AprilTagDetectorNode {
  private:
    ros::NodeHandle nh_;
    ros::Publisher tag_detections_pub_;
    ros::Publisher tag_pose_pub_;

    // RealSense相关
    rs2::pipeline p_;
    rs2::config cfg_;

    // AprilTag相关
    apriltag_detector_t *td_;
    apriltag_family_t *tf_;

    // 相机参数
    double fx_, fy_, cx_, cy_;
    const double tag_size_ = 0.143; // AprilTag大小，单位：米

    // 检测参数
    bool enable_visualization_;
    bool enable_pose_estimation_;

  public:
    AprilTagDetectorNode() : nh_("~") {
        // 初始化发布者
        tag_detections_pub_ = nh_.advertise<fast_lio::AprilTagDetectionArray>(
            "/apriltag_detections", 10);
        tag_pose_pub_ =
            nh_.advertise<geometry_msgs::PoseStamped>("/apriltag_pose", 10);

        // 从参数服务器获取参数
        nh_.param<bool>("enable_visualization", enable_visualization_, true);
        nh_.param<bool>("enable_pose_estimation", enable_pose_estimation_,
                        true);

        // 初始化RealSense
        initializeRealSense();

        // 初始化AprilTag检测器
        initializeAprilTagDetector();

        ROS_INFO("AprilTag检测节点已启动");
    }

    ~AprilTagDetectorNode() {
        // 清理资源
        if (td_) {
            apriltag_detector_destroy(td_);
        }
        if (tf_) {
            tag36h11_destroy(tf_);
        }
        p_.stop();
    }

    void initializeRealSense() {
        try {
            cfg_.enable_stream(RS2_STREAM_COLOR, 1280, 720, RS2_FORMAT_BGR8, 30);
            p_.start(cfg_);

            // 等待一些帧以允许自动曝光稳定
            for (int i = 0; i < 30; ++i) {
                p_.wait_for_frames();
            }

            // 获取相机内参
            getCameraIntrinsics();

            ROS_INFO("RealSense相机初始化成功");
        } catch (const rs2::error &e) {
            ROS_ERROR("RealSense初始化失败: %s", e.what());
            throw;
        }
    }

    void initializeAprilTagDetector() {
        // 创建AprilTag检测器
        td_ = apriltag_detector_create();
        tf_ = tag36h11_create();
        apriltag_detector_add_family(td_, tf_);

        // 设置检测参数
        td_->quad_decimate = 2.0; // 降低图像分辨率以提高速度
        td_->quad_sigma = 0.0;    // 高斯模糊
        td_->nthreads = 4;        // 线程数
        td_->debug = 0;           // 调试模式
        td_->refine_edges = 1;    // 边缘优化

        // ROS_INFO("AprilTag检测器初始化成功");
        // ROS_INFO("标签大小: %.3f 米", tag_size_);
        // ROS_INFO("相机内参: fx=%.2f, fy=%.2f, cx=%.2f, cy=%.2f", fx_, fy_, cx_,
        //          cy_);
    }

    void getCameraIntrinsics() {
        // 等待一帧以获取传感器信息
        auto frames = p_.wait_for_frames();
        auto color_frame = frames.get_color_frame();

        // 获取内参
        auto color_intrin = color_frame.get_profile()
                                .as<rs2::video_stream_profile>()
                                .get_intrinsics();

        fx_ = color_intrin.fx;
        fy_ = color_intrin.fy;
        cx_ = color_intrin.ppx;
        cy_ = color_intrin.ppy;
    }

    void rotationMatrixToEulerAngles(const cv::Mat &R, double &roll,
                                     double &pitch, double &yaw) {
        // 检查万向节锁（Gimbal Lock）
        if (std::abs(R.at<double>(2, 0)) != 1.0) {
            pitch = -std::asin(R.at<double>(2, 0));
            roll = std::atan2(R.at<double>(2, 1) / std::cos(pitch),
                              R.at<double>(2, 2) / std::cos(pitch));
            yaw = std::atan2(R.at<double>(1, 0) / std::cos(pitch),
                             R.at<double>(0, 0) / std::cos(pitch));
        } else {
            // 万向节锁情况
            yaw = 0;
            if (R.at<double>(2, 0) == -1) {
                pitch = M_PI / 2;
                roll = yaw + std::atan2(R.at<double>(0, 1), R.at<double>(0, 2));
            } else {
                pitch = -M_PI / 2;
                roll =
                    -yaw + std::atan2(-R.at<double>(0, 1), -R.at<double>(0, 2));
            }
        }
    }

    double rad2deg(double rad) { return rad * 180.0 / M_PI; }

    bool estimatePoseOpenCV(const apriltag_detection_t *det, cv::Mat &rvec,
                            cv::Mat &tvec) {
        try {
            // 构建3D点（标签的四个角点，以标签中心为原点）
            std::vector<cv::Point3f> objectPoints;
            double half_size = tag_size_ / 2.0;
            objectPoints.push_back(cv::Point3f(-half_size, -half_size, 0));
            objectPoints.push_back(cv::Point3f(half_size, -half_size, 0));
            objectPoints.push_back(cv::Point3f(half_size, half_size, 0));
            objectPoints.push_back(cv::Point3f(-half_size, half_size, 0));

            // 构建2D点（检测到的角点）
            std::vector<cv::Point2f> imagePoints;
            for (int i = 0; i < 4; i++) {
                imagePoints.push_back(cv::Point2f(det->p[i][0], det->p[i][1]));
            }

            // 构建相机矩阵
            cv::Mat cameraMatrix =
                (cv::Mat_<double>(3, 3) << fx_, 0, cx_, 0, fy_, cy_, 0, 0, 1);

            // 构建畸变系数（假设无畸变）
            cv::Mat distCoeffs = cv::Mat::zeros(4, 1, CV_64F);

            // 使用PnP求解位姿
            bool success = cv::solvePnP(objectPoints, imagePoints, cameraMatrix,
                                        distCoeffs, rvec, tvec);

            return success;
        } catch (const std::exception &e) {
            ROS_ERROR("OpenCV位姿估计错误: %s", e.what());
            return false;
        }
    }

    void processFrame() {
        try {
            // 等待并捕获一帧
            rs2::frameset frames = p_.wait_for_frames();
            rs2::frame color_frame = frames.get_color_frame();

            // 获取帧的宽高
            auto width = color_frame.as<rs2::video_frame>().get_width();
            auto height = color_frame.as<rs2::video_frame>().get_height();

            // 转换为OpenCV格式
            cv::Mat color_image(cv::Size(width, height), CV_8UC3,
                                (void *)color_frame.get_data(),
                                cv::Mat::AUTO_STEP);
            cv::Mat gray_image;
            cv::cvtColor(color_image, gray_image, cv::COLOR_BGR2GRAY);

            // 创建AprilTag图像格式
            image_u8_t im = {.width = gray_image.cols,
                             .height = gray_image.rows,
                             .stride = gray_image.cols,
                             .buf = gray_image.data};

            // 检测AprilTag
            zarray_t *detections = apriltag_detector_detect(td_, &im);

            // 创建ROS消息
            fast_lio::AprilTagDetectionArray detection_array;
            detection_array.header.stamp = ros::Time::now();
            detection_array.header.frame_id = "camera_color_optical_frame";

            // 处理检测结果
            for (int i = 0; i < zarray_size(detections); i++) {
                apriltag_detection_t *det;
                zarray_get(detections, i, &det);

                // 创建检测消息
                fast_lio::AprilTagDetection detection_msg;
                detection_msg.id = det->id;
                detection_msg.size = tag_size_;

                // 设置角点坐标
                for (int j = 0; j < 4; j++) {
                    geometry_msgs::Point32 point;
                    point.x = det->p[j][0];
                    point.y = det->p[j][1];
                    point.z = 0;
                    detection_msg.corners.push_back(point);
                }

                // 设置中心点
                geometry_msgs::Point32 center;
                center.x = det->c[0];
                center.y = det->c[1];
                center.z = 0;
                detection_msg.center = center;

                // 位姿估计
                if (enable_pose_estimation_) {
                    cv::Mat rvec, tvec;
                    bool pose_success = estimatePoseOpenCV(det, rvec, tvec);

                    if (pose_success) {
                        // 获取平移向量
                        double x = tvec.at<double>(0);
                        double y = tvec.at<double>(1);
                        double z = tvec.at<double>(2);

                        // 将旋转向量转换为旋转矩阵
                        cv::Mat R;
                        cv::Rodrigues(rvec, R);

                        // 计算欧拉角
                        double roll, pitch, yaw;
                        rotationMatrixToEulerAngles(R, roll, pitch, yaw);

                        // 创建位姿消息
                        geometry_msgs::PoseStamped pose_msg;
                        pose_msg.header.stamp = ros::Time::now();
                        pose_msg.header.frame_id = "camera_color_optical_frame";

                        // 设置位置
                        pose_msg.pose.position.x = x;
                        pose_msg.pose.position.y = y;
                        pose_msg.pose.position.z = z;

                        // 将旋转矩阵转换为四元数
                        double qw =
                            sqrt(1.0 + R.at<double>(0, 0) + R.at<double>(1, 1) +
                                 R.at<double>(2, 2)) /
                            2.0;
                        double qx = (R.at<double>(2, 1) - R.at<double>(1, 2)) /
                                    (4.0 * qw);
                        double qy = (R.at<double>(0, 2) - R.at<double>(2, 0)) /
                                    (4.0 * qw);
                        double qz = (R.at<double>(1, 0) - R.at<double>(0, 1)) /
                                    (4.0 * qw);

                        pose_msg.pose.orientation.x = qx;
                        pose_msg.pose.orientation.y = qy;
                        pose_msg.pose.orientation.z = qz;
                        pose_msg.pose.orientation.w = qw;

                        // 设置检测消息的位姿
                        detection_msg.pose = pose_msg.pose;

                        // 发布位姿消息
                        tag_pose_pub_.publish(pose_msg);

                        // 打印检测信息
                        double distance = cv::norm(tvec);
                        // ROS_INFO(
                        //     "检测到标签 ID: %d, 距离: %.3f米, 位置: (%.3f, "
                        //     "%.3f, %.3f), 姿态: (%.1f°, %.1f°, %.1f°)",
                        //     det->id, distance, x, y, z, rad2deg(roll),
                        //     rad2deg(pitch), rad2deg(yaw));
                    }
                }

                detection_array.detections.push_back(detection_msg);
            }

            // 发布检测结果
            tag_detections_pub_.publish(detection_array);

            // 可视化（如果启用）
            if (enable_visualization_) {
                visualizeDetections(color_image, detections);
            }

            // 释放检测结果
            apriltag_detections_destroy(detections);

        } catch (const rs2::error &e) {
            ROS_ERROR("RealSense错误: %s", e.what());
        } catch (const std::exception &e) {
            ROS_ERROR("处理帧时发生错误: %s", e.what());
        }
    }

    void visualizeDetections(cv::Mat &color_image, zarray_t *detections) {
        for (int i = 0; i < zarray_size(detections); i++) {
            apriltag_detection_t *det;
            zarray_get(detections, i, &det);

            // 绘制标签边框
            for (int j = 0; j < 4; j++) {
                cv::line(
                    color_image, cv::Point(det->p[j][0], det->p[j][1]),
                    cv::Point(det->p[(j + 1) % 4][0], det->p[(j + 1) % 4][1]),
                    cv::Scalar(0, 255, 0), 2);
            }

            // 绘制标签ID
            std::stringstream ss;
            ss << "ID:" << det->id;
            cv::putText(color_image, ss.str(), cv::Point(det->c[0], det->c[1]),
                        cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 255),
                        2);
        }

        // 显示图像
        cv::imshow("AprilTag检测", color_image);
        cv::waitKey(1);
    }

    void run() {
        ros::Rate rate(30); // 30Hz

        while (ros::ok()) {
            processFrame();
            ros::spinOnce();
            rate.sleep();
        }
    }
};

int main(int argc, char **argv) {
    ros::init(argc, argv, "apriltag_detector");

    try {
        AprilTagDetectorNode node;
        node.run();
    } catch (const std::exception &e) {
        ROS_ERROR("节点运行失败: %s", e.what());
        return 1;
    }

    return 0;
}
