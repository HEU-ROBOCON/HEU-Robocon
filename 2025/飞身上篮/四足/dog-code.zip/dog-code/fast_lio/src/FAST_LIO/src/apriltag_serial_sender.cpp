#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <fast_lio/AprilTagDetectionArray.h>
#include <serial/serial.h>
#include <string>
#include <vector>

// 定义数据包结构
#pragma pack(1)  // 1字节对齐
struct AprilTagData {
    uint8_t header[2] = {0x0A, 0x0B};  // 包头
    uint8_t tag_id;                    // 标签ID
    float x;                           // 位置x (厘米)
    float y;                           // 位置y (厘米)
    float z;                           // 位置z (厘米)
    float roll;                        // 姿态roll (度)
    float pitch;                       // 姿态pitch (度)
    float yaw;                         // 姿态yaw (度)
    uint8_t tail[2] = {0x0C, 0x0D};    // 包尾
} apriltag_data;
#pragma pack()

serial::Serial ser;  // 串口对象

void apriltagCallback(const fast_lio::AprilTagDetectionArray::ConstPtr& msg)
{
    if (msg->detections.empty()) {
        return;  // 没有检测到AprilTag，不发送数据
    }
    
    // 获取第一个检测到的AprilTag（如果有多个，可以选择最近的或ID最小的）
    const fast_lio::AprilTagDetection& detection = msg->detections[0];
    
    // 设置标签ID
    apriltag_data.tag_id = detection.id;
    
    // 设置位置（转换为厘米）
    apriltag_data.x = detection.pose.position.x * 100.0;
    apriltag_data.y = detection.pose.position.y * 100.0;
    apriltag_data.z = detection.pose.position.z * 100.0;
    
    // 将四元数转换为欧拉角
    double qx = detection.pose.orientation.x;
    double qy = detection.pose.orientation.y;
    double qz = detection.pose.orientation.z;
    double qw = detection.pose.orientation.w;
    
    // 计算欧拉角
    double roll, pitch, yaw;
    
    // 四元数转欧拉角
    double sinr_cosp = 2 * (qw * qx + qy * qz);
    double cosr_cosp = 1 - 2 * (qx * qx + qy * qy);
    roll = std::atan2(sinr_cosp, cosr_cosp);
    
    double sinp = 2 * (qw * qy - qz * qx);
    if (std::abs(sinp) >= 1) {
        pitch = std::copysign(M_PI / 2, sinp);  // 使用90度，如果超出范围
    } else {
        pitch = std::asin(sinp);
    }
    
    double siny_cosp = 2 * (qw * qz + qx * qy);
    double cosy_cosp = 1 - 2 * (qy * qy + qz * qz);
    yaw = std::atan2(siny_cosp, cosy_cosp);
    
    // 转换为角度
    apriltag_data.roll = roll * 180.0 / M_PI;
    apriltag_data.pitch = pitch * 180.0 / M_PI;
    apriltag_data.yaw = yaw * 180.0 / M_PI;
    
    // 发送数据
    if (ser.isOpen()) {
        try {
            ser.write(
                reinterpret_cast<uint8_t*>(&apriltag_data),
                sizeof(AprilTagData)
            );
            
            // 打印发送的数据（调试用）
            ROS_INFO("Sent AprilTag data: ID=%d, x=%.1fcm, y=%.1fcm, z=%.1fcm, roll=%.1f°, pitch=%.1f°, yaw=%.1f°",
                     apriltag_data.tag_id, apriltag_data.x, apriltag_data.y, apriltag_data.z,
                     apriltag_data.roll, apriltag_data.pitch, apriltag_data.yaw);
        }
        catch (serial::IOException& e) {
            ROS_ERROR_STREAM("Serial write error: " << e.what());
        }
    }
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "apriltag_serial_sender");
    ros::NodeHandle nh;

    // 从参数服务器获取串口参数
    std::string port;
    int baudrate;
    nh.param<std::string>("serial_port", port, "/dev/ttyUSB0");
    nh.param<int>("baudrate", baudrate, 115200);

    try {
        // 配置串口
        ser.setPort(port);
        ser.setBaudrate(baudrate);
        serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(timeout);
        ser.open();
    }
    catch (serial::IOException& e) {
        ROS_ERROR_STREAM("Unable to open serial port: " << e.what());
        return -1;
    }

    if(ser.isOpen()) {
        ROS_INFO_STREAM("Serial port " << port << " opened successfully");
    } else {
        ROS_ERROR_STREAM("Failed to open serial port " << port);
        return -1;
    }

    // 订阅AprilTag检测话题
    ros::Subscriber sub = nh.subscribe("/apriltag_detections", 10, apriltagCallback);

    ROS_INFO("开始通过串口发送AprilTag数据...");
    ros::spin();

    // 关闭串口
    if(ser.isOpen()) {
        ser.close();
    }

    return 0;
} 
