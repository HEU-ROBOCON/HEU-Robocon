#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <serial/serial.h>
#include <string>
#include <tf/tf.h>
#include <vector>

#pragma pack(1) // 1字节对齐
struct PoseData {
    uint8_t header[2] = {0x0A, 0x0B}; // 包头
    float x;                          // 位置x
    float y;                          // 位置y
    float z;                          // 位置z
    // float roll;                        // 姿态roll
    // float pitch;                       // 姿态pitch
    // float yaw;                         // 姿态yaw
    uint8_t tail[2] = {0x0C, 0x0D}; // 包尾
} pose_data;

#pragma pack()
float roll;
float pitch;
float yaw;
serial::Serial ser;

void odomCallback(const nav_msgs::Odometry::ConstPtr &msg) {
    pose_data.x = msg->pose.pose.position.x * 100;
    pose_data.y = msg->pose.pose.position.y * 100;
    pose_data.z = msg->pose.pose.position.z * 100;

    double qx = msg->pose.pose.orientation.x;
    double qy = msg->pose.pose.orientation.y;
    double qz = msg->pose.pose.orientation.z;
    double qw = msg->pose.pose.orientation.w;

    tf::Quaternion q(qx, qy, qz, qw);
    tf::Matrix3x3 m(q);
    double roll, pitch, yaw;
    m.getRPY(roll, pitch, yaw);

    // 转换为角度并存储
    roll = roll * 180.0 / M_PI;
    pitch = pitch * 180.0 / M_PI;
    yaw = yaw * 180.0 / M_PI;
    if (ser.isOpen()) {
        try {
            ser.write(reinterpret_cast<uint8_t *>(&pose_data),
                      sizeof(PoseData));

            ROS_INFO("Sent pose data: x=%.3f, y=%.3f, z=%.3f, roll=%.3f, "
                     "pitch=%.3f, yaw=%.3f",
                     pose_data.x, pose_data.y, pose_data.z, roll, pitch, yaw);
            // ROS_INFO("Sent pose data: x=%.2f, y=%.2f, z=%.2f", pose_data.x,
            //          pose_data.y, pose_data.z);
        } catch (serial::IOException &e) {
            ROS_ERROR_STREAM("Serial write error: " << e.what());
        }
    }
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "pose_serial_sender");
    ros::NodeHandle nh;

    // 从参数服务器获取串口参数
    std::string port;
    int baudrate;
    nh.param<std::string>("serial_port", port, "/dev/ttyUSB0");
    nh.param<int>("baudrate", baudrate, 115200);

    try {
        ser.setPort(port);
        ser.setBaudrate(baudrate);
        serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(timeout);
        ser.open();
    } catch (serial::IOException &e) {
        ROS_ERROR_STREAM("Unable to open serial port: " << e.what());
        return -1;
    }

    if (ser.isOpen()) {
        ROS_INFO_STREAM("Serial port " << port << " opened successfully");
    } else {
        ROS_ERROR_STREAM("Failed to open serial port " << port);
        return -1;
    }

    // 订阅Odometry话题
    ros::Subscriber sub = nh.subscribe("/Odometry", 20, odomCallback);

    ROS_INFO("开始通过串口发送位姿数据...");
    ros::spin();

    // 关闭串口
    if (ser.isOpen()) {
        ser.close();
    }

    return 0;
}
