#include <apriltag.h>
#include <apriltag_math.h>
#include <apriltag_pose.h>
#include <cmath>
#include <iomanip>              // 用于格式化输出
#include <iostream>             // 用于控制台输出
#include <librealsense2/rs.hpp> // RealSense SDK头文件
#include <opencv2/opencv.hpp>   // OpenCV头文件
#include <sstream>              // 用于字符串流操作
#include <tag36h11.h>
#include <vector>

const double tag_size = 0.143;

// 将旋转矩阵转换为欧拉角（roll, pitch, yaw）
void rotationMatrixToEulerAngles(const cv::Mat &R, double &roll, double &pitch,
                                 double &yaw) {
    // 检查万向节锁（Gimbal Lock）
    if (std::abs(R.at<double>(2, 0)) != 1.0) {
        pitch = -std::asin(R.at<double>(2, 0));
        roll = std::atan2(R.at<double>(2, 1) / std::cos(pitch),
                          R.at<double>(2, 2) / std::cos(pitch));
        yaw = std::atan2(R.at<double>(1, 0) / std::cos(pitch),
                         R.at<double>(0, 0) / std::cos(pitch));
    } else {
        // 万向节锁情况
        yaw = 0;
        if (R.at<double>(2, 0) == -1) {
            pitch = M_PI / 2;
            roll = yaw + std::atan2(R.at<double>(0, 1), R.at<double>(0, 2));
        } else {
            pitch = -M_PI / 2;
            roll = -yaw + std::atan2(-R.at<double>(0, 1), -R.at<double>(0, 2));
        }
    }
}

// 将弧度转换为角度
double rad2deg(double rad) { return rad * 180.0 / M_PI; }

// 获取相机内参的函数
void get_camera_intrinsics(const rs2::pipeline &pipe, double &fx, double &fy,
                           double &cx, double &cy) {
    // 等待一帧以获取传感器信息
    auto frames = pipe.wait_for_frames();
    auto color_frame = frames.get_color_frame();

    // 获取内参
    auto color_intrin = color_frame.get_profile()
                            .as<rs2::video_stream_profile>()
                            .get_intrinsics();

    fx = color_intrin.fx;
    fy = color_intrin.fy;
    cx = color_intrin.ppx;
    cy = color_intrin.ppy;

    std::cout << "获取到相机内参：" << std::endl;
    std::cout << "fx: " << fx << std::endl;
    std::cout << "fy: " << fy << std::endl;
    std::cout << "cx: " << cx << std::endl;
    std::cout << "cy: " << cy << std::endl;
}

// 使用OpenCV进行位姿估计
bool estimate_pose_opencv(const apriltag_detection_t *det, const double fx,
                          const double fy, const double cx, const double cy,
                          const double tag_size, cv::Mat &rvec, cv::Mat &tvec) {
    try {
        // 构建3D点（标签的四个角点，以标签中心为原点）
        std::vector<cv::Point3f> objectPoints;
        double half_size = tag_size / 2.0;
        objectPoints.push_back(cv::Point3f(-half_size, -half_size, 0));
        objectPoints.push_back(cv::Point3f(half_size, -half_size, 0));
        objectPoints.push_back(cv::Point3f(half_size, half_size, 0));
        objectPoints.push_back(cv::Point3f(-half_size, half_size, 0));

        // 构建2D点（检测到的角点）
        std::vector<cv::Point2f> imagePoints;
        for (int i = 0; i < 4; i++) {
            imagePoints.push_back(cv::Point2f(det->p[i][0], det->p[i][1]));
        }

        // 构建相机矩阵
        cv::Mat cameraMatrix =
            (cv::Mat_<double>(3, 3) << fx, 0, cx, 0, fy, cy, 0, 0, 1);

        // 构建畸变系数（假设无畸变）
        cv::Mat distCoeffs = cv::Mat::zeros(4, 1, CV_64F);

        // 使用PnP求解位姿
        bool success = cv::solvePnP(objectPoints, imagePoints, cameraMatrix,
                                    distCoeffs, rvec, tvec);

        return success;
    } catch (const std::exception &e) {
        std::cerr << "OpenCV位姿估计错误: " << e.what() << std::endl;
        return false;
    }
}

int main() try {
    // 创建RealSense管道
    rs2::pipeline p;
    rs2::config cfg;
    cfg.enable_stream(RS2_STREAM_COLOR, 640, 480, RS2_FORMAT_BGR8, 30);
    p.start(cfg);

    // 等待一些帧以允许自动曝光稳定
    for (int i = 0; i < 30; ++i) {
        p.wait_for_frames();
    }

    // 获取实际相机内参
    double fx, fy, cx, cy;
    get_camera_intrinsics(p, fx, fy, cx, cy);

    // 创建AprilTag检测器
    apriltag_detector_t *td = apriltag_detector_create();
    apriltag_family_t *tf = tag36h11_create();
    apriltag_detector_add_family(td, tf);
    td->quad_decimate = 2.0; // 降低图像分辨率以提高速度
    td->quad_sigma = 0.0;    // 高斯模糊
    td->nthreads = 4;        // 线程数
    td->debug = 0;           // 调试模式
    td->refine_edges = 1;    // 边缘优化

    // 创建相机内参矩阵
    apriltag_detection_info_t info;
    info.tagsize = tag_size;
    info.fx = fx;
    info.fy = fy;
    info.cx = cx;
    info.cy = cy;

    std::cout << "AprilTag检测器配置：" << std::endl;
    std::cout << "标签大小: " << info.tagsize << " 米" << std::endl;
    std::cout << "相机内参: fx=" << info.fx << ", fy=" << info.fy
              << ", cx=" << info.cx << ", cy=" << info.cy << std::endl;

    while (true) {
        // 等待并捕获一帧
        rs2::frameset frames = p.wait_for_frames();
        rs2::frame color_frame = frames.get_color_frame();

        // 获取帧的宽高
        auto width = color_frame.as<rs2::video_frame>().get_width();
        auto height = color_frame.as<rs2::video_frame>().get_height();

        // 转换为OpenCV格式
        cv::Mat color_image(cv::Size(width, height), CV_8UC3,
                            (void *)color_frame.get_data(), cv::Mat::AUTO_STEP);
        cv::Mat gray_image;
        cv::cvtColor(color_image, gray_image, cv::COLOR_BGR2GRAY);

        // 创建AprilTag图像格式
        image_u8_t im = {.width = gray_image.cols,
                         .height = gray_image.rows,
                         .stride = gray_image.cols,
                         .buf = gray_image.data};

        // 检测AprilTag
        zarray_t *detections = apriltag_detector_detect(td, &im);

        // 处理检测结果
        for (int i = 0; i < zarray_size(detections); i++) {
            apriltag_detection_t *det;
            zarray_get(detections, i, &det);

            // 打印检测到的角点坐标，用于调试
            std::cout << "标签角点坐标：" << std::endl;
            for (int j = 0; j < 4; j++) {
                std::cout << "点" << j << ": (" << det->p[j][0] << ", "
                          << det->p[j][1] << ")" << std::endl;
            }

            // 使用OpenCV进行位姿估计
            cv::Mat rvec, tvec;
            bool pose_success =
                estimate_pose_opencv(det, fx, fy, cx, cy, tag_size, rvec, tvec);

            // 声明欧拉角变量
            double roll = 0.0, pitch = 0.0, yaw = 0.0;

            if (pose_success) {
                // 打印标签信息
                std::cout << "检测到标签 ID: " << det->id << std::endl;
                std::cout << "中心点像素坐标: (" << det->c[0] << ", "
                          << det->c[1] << ")" << std::endl;

                // 获取平移向量
                double x = tvec.at<double>(0);
                double y = tvec.at<double>(1);
                double z = tvec.at<double>(2);

                // 将旋转向量转换为旋转矩阵
                cv::Mat R;
                cv::Rodrigues(rvec, R);

                // 计算欧拉角
                rotationMatrixToEulerAngles(R, roll, pitch, yaw);

                // 转换为角度
                roll = rad2deg(roll);
                pitch = rad2deg(pitch);
                yaw = rad2deg(yaw);

                // 打印位姿信息
                std::cout << "位姿 (x,y,z,roll,pitch,yaw):" << std::endl;
                std::cout << std::fixed << std::setprecision(3)
                          << "x: " << std::setw(8) << x << " m, "
                          << "y: " << std::setw(8) << y << " m, "
                          << "z: " << std::setw(8) << z << " m, "
                          << "roll: " << std::setw(8) << roll << "°, "
                          << "pitch: " << std::setw(8) << pitch << "°, "
                          << "yaw: " << std::setw(8) << yaw << "°" << std::endl;

                // 计算标签到相机的距离
                double distance = cv::norm(tvec);
                std::cout << "标签到相机的距离: " << std::fixed
                          << std::setprecision(3) << distance << " 米"
                          << std::endl;
            } else {
                std::cout << "位姿估计失败！" << std::endl;
            }
            std::cout << "-------------------" << std::endl;

            // 在图像上绘制检测结果
            // 绘制标签边框
            for (int j = 0; j < 4; j++) {
                cv::line(
                    color_image, cv::Point(det->p[j][0], det->p[j][1]),
                    cv::Point(det->p[(j + 1) % 4][0], det->p[(j + 1) % 4][1]),
                    cv::Scalar(0, 255, 0), 2);
            }

            // 绘制标签ID和位姿信息
            std::stringstream ss;
            ss << "ID:" << det->id;
            if (pose_success) {
                ss << " d:" << std::fixed << std::setprecision(2)
                   << cv::norm(tvec) << "m";
                // 在图像上显示欧拉角
                ss << " r:" << std::fixed << std::setprecision(1) << roll
                   << "°";
            }

            cv::putText(color_image, ss.str(), cv::Point(det->c[0], det->c[1]),
                        cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 255),
                        2);
        }

        // 释放检测结果
        apriltag_detections_destroy(detections);

        // 显示图像
        cv::imshow("AprilTag检测", color_image);

        // 按'q'退出
        if (cv::waitKey(1) == 'q') {
            break;
        }
    }

    // 清理资源
    apriltag_detector_destroy(td);
    tag36h11_destroy(tf);
    p.stop();

    return 0;
} catch (const rs2::error &e) {
    std::cerr << "RealSense错误: " << e.what() << std::endl;
    return 1;
} catch (const std::exception &e) {
    std::cerr << "通用错误: " << e.what() << std::endl;
    return 1;
}
