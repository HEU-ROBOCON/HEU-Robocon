#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <visualization_msgs/Marker.h>
#include <livox_ros_driver2/CustomMsg.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/features/normal_3d.h>
#include <pcl/search/kdtree.h>
#include <cmath>

class CylinderDetector {
private:
    ros::NodeHandle nh_;
    ros::Subscriber cloud_sub_;
    ros::Publisher cylinder_cloud_pub_;    // 发布检测到的圆筒点云
    ros::Publisher cylinder_marker_pub_;   // 发布圆柱体模型标记
    ros::Publisher original_cloud_pub_;    // 发布原始点云
    
    // 圆筒参数
    const double CYLINDER_HEIGHT = 0.6;    // 圆筒高度(m)
    const double CYLINDER_RADIUS = 0.1;    // 圆筒半径(m)
    const double RADIUS_TOLERANCE = 0.05;  // 半径容差(m)
    const double HEIGHT_TOLERANCE = 0.2;   // 高度容差(m)

    // 点云处理参数
    const double VOXEL_SIZE = 0.02;        // 体素滤波大小
    const double DISTANCE_THRESHOLD = 0.02; // RANSAC距离阈值
    const int MAX_ITERATIONS = 1000;       // RANSAC最大迭代次数
    const double NORMAL_RADIUS = 0.03;     // 法线估计搜索半径

    // 检测阈值
    const double MIN_INLIER_RATIO = 0.10;  // 最小内点比例（10%）
    const int MIN_INLIER_POINTS = 30;      // 最小内点数量

public:
    CylinderDetector() {
        // 订阅FAST-LIO发布的点云话题
        cloud_sub_ = nh_.subscribe("/cloud_registered_body", 1, &CylinderDetector::cloudCallback, this);
        // 发布检测到的圆筒点云
        cylinder_cloud_pub_ = nh_.advertise<sensor_msgs::PointCloud2>("/cylinder_cloud", 1);
        // 发布圆柱体模型标记
        cylinder_marker_pub_ = nh_.advertise<visualization_msgs::Marker>("/cylinder_marker", 1);
        // 发布原始点云
        original_cloud_pub_ = nh_.advertise<sensor_msgs::PointCloud2>("/original_cloud", 1);
        
        ROS_INFO("Cylinder detector node started, waiting for point cloud data...");
        ROS_INFO("Subscribed topic: /cloud_registered_body");
        ROS_INFO("Target cylinder parameters: height=%.2fm, radius=%.2fm", CYLINDER_HEIGHT, CYLINDER_RADIUS);
    }

    void cloudCallback(const sensor_msgs::PointCloud2::ConstPtr& cloud_msg) {
        // 发布原始点云
        original_cloud_pub_.publish(*cloud_msg);
        
        ROS_INFO("Received point cloud, timestamp: %.3f", cloud_msg->header.stamp.toSec());
        
        // 转换为PCL点云格式
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::fromROSMsg(*cloud_msg, *cloud);
        ROS_INFO("Original point cloud size: %lu", cloud->points.size());

        if (cloud->points.empty()) {
            ROS_WARN("Received empty point cloud!");
            return;
        }

        // 1. 体素滤波降采样
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::VoxelGrid<pcl::PointXYZ> voxel_filter;
        voxel_filter.setInputCloud(cloud);
        voxel_filter.setLeafSize(VOXEL_SIZE, VOXEL_SIZE, VOXEL_SIZE);
        voxel_filter.filter(*cloud_filtered);
        ROS_INFO("Points after voxel filter: %lu", cloud_filtered->points.size());

        // 2. 高度过滤（假设地面在z=0）
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_height_filtered(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::PassThrough<pcl::PointXYZ> height_filter;
        height_filter.setInputCloud(cloud_filtered);
        height_filter.setFilterFieldName("z");
        height_filter.setFilterLimits(0.0, CYLINDER_HEIGHT + HEIGHT_TOLERANCE);
        height_filter.filter(*cloud_height_filtered);
        ROS_INFO("Points after height filter: %lu", cloud_height_filtered->points.size());

        if (cloud_height_filtered->points.empty()) {
            ROS_WARN("Point cloud empty after height filtering!");
            return;
        }

        // 3. 计算法线
        pcl::PointCloud<pcl::Normal>::Ptr cloud_normals(new pcl::PointCloud<pcl::Normal>);
        pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
        pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ>());
        ne.setInputCloud(cloud_height_filtered);
        ne.setSearchMethod(tree);
        ne.setRadiusSearch(NORMAL_RADIUS);
        ne.compute(*cloud_normals);
        ROS_INFO("Normal estimation completed, normal points: %lu", cloud_normals->points.size());

        // 4. 圆柱体分割
        pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
        pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
        pcl::SACSegmentationFromNormals<pcl::PointXYZ, pcl::Normal> seg;
        seg.setOptimizeCoefficients(true);
        seg.setModelType(pcl::SACMODEL_CYLINDER);
        seg.setMethodType(pcl::SAC_RANSAC);
        seg.setMaxIterations(MAX_ITERATIONS);
        seg.setDistanceThreshold(DISTANCE_THRESHOLD);
        seg.setRadiusLimits(CYLINDER_RADIUS - RADIUS_TOLERANCE, 
                           CYLINDER_RADIUS + RADIUS_TOLERANCE);
        seg.setInputCloud(cloud_height_filtered);
        seg.setInputNormals(cloud_normals);
        seg.segment(*inliers, *coefficients);

        if (inliers->indices.size() > 0) {
            // 计算内点比例
            float inlier_ratio = (float)inliers->indices.size() / cloud_height_filtered->points.size();
            
            // 检查是否满足内点比例和数量阈值
            if (inlier_ratio >= MIN_INLIER_RATIO && inliers->indices.size() >= MIN_INLIER_POINTS) {
                // 提取圆柱体点云
                pcl::PointCloud<pcl::PointXYZ>::Ptr cylinder_cloud(new pcl::PointCloud<pcl::PointXYZ>);
                pcl::ExtractIndices<pcl::PointXYZ> extract;
                extract.setInputCloud(cloud_height_filtered);
                extract.setIndices(inliers);
                extract.setNegative(false);
                extract.filter(*cylinder_cloud);

                // 发布检测到的圆筒点云
                sensor_msgs::PointCloud2 cylinder_cloud_msg;
                pcl::toROSMsg(*cylinder_cloud, cylinder_cloud_msg);
                cylinder_cloud_msg.header = cloud_msg->header;
                cylinder_cloud_pub_.publish(cylinder_cloud_msg);

                // 创建圆柱体模型标记
                visualization_msgs::Marker marker;
                marker.header = cloud_msg->header;
                marker.ns = "cylinder";
                marker.id = 0;
                marker.type = visualization_msgs::Marker::CYLINDER;
                marker.action = visualization_msgs::Marker::ADD;

                // 设置圆柱体位置和方向
                float center_x = coefficients->values[0];
                float center_y = coefficients->values[1];
                float center_z = coefficients->values[2];
                float radius = coefficients->values[6];

                // 计算到激光雷达的距离
                float distance = std::sqrt(center_x * center_x + center_y * center_y + center_z * center_z);

                // 设置圆柱体位置和方向
                marker.pose.position.x = center_x;
                marker.pose.position.y = center_y;
                marker.pose.position.z = center_z;

                // 设置圆柱体方向（使用法向量）
                double dx = coefficients->values[3];
                double dy = coefficients->values[4];
                double dz = coefficients->values[5];
                double length = std::sqrt(dx*dx + dy*dy + dz*dz);
                
                // 计算旋转四元数
                double angle = std::acos(dz/length);
                double axis_x = -dy;
                double axis_y = dx;
                double axis_z = 0;
                double axis_length = std::sqrt(axis_x*axis_x + axis_y*axis_y);
                
                if (axis_length > 0) {
                    axis_x /= axis_length;
                    axis_y /= axis_length;
                    marker.pose.orientation.x = axis_x * std::sin(angle/2);
                    marker.pose.orientation.y = axis_y * std::sin(angle/2);
                    marker.pose.orientation.z = 0;
                    marker.pose.orientation.w = std::cos(angle/2);
                } else {
                    marker.pose.orientation.w = 1.0;
                }

                // 设置圆柱体尺寸
                marker.scale.x = radius * 2;  // 直径
                marker.scale.y = radius * 2;  // 直径
                marker.scale.z = CYLINDER_HEIGHT;  // 高度

                // 设置颜色（红色，半透明）
                marker.color.r = 1.0;
                marker.color.g = 0.0;
                marker.color.b = 0.0;
                marker.color.a = 0.5;

                cylinder_marker_pub_.publish(marker);

                // 打印详细结果
                ROS_INFO("Cylinder detected (passed threshold check):");
                ROS_INFO("- Position: (%.3f, %.3f, %.3f)", center_x, center_y, center_z);
                ROS_INFO("- Distance: %.3f meters", distance);
                ROS_INFO("- Fitted radius: %.3f meters", radius);
                ROS_INFO("- Inlier points: %lu (threshold: %d)", inliers->indices.size(), MIN_INLIER_POINTS);
                ROS_INFO("- Inlier ratio: %.2f%% (threshold: %.1f%%)", 
                         inlier_ratio * 100, MIN_INLIER_RATIO * 100);
            } else {
                // 清除之前的标记
                visualization_msgs::Marker marker;
                marker.header = cloud_msg->header;
                marker.ns = "cylinder";
                marker.id = 0;
                marker.action = visualization_msgs::Marker::DELETE;
                cylinder_marker_pub_.publish(marker);

                ROS_INFO("Cylinder detection failed threshold check:");
                ROS_INFO("- Inlier points: %lu (threshold: %d)", inliers->indices.size(), MIN_INLIER_POINTS);
                ROS_INFO("- Inlier ratio: %.2f%% (threshold: %.1f%%)", 
                         inlier_ratio * 100, MIN_INLIER_RATIO * 100);
            }
        } else {
            // 清除之前的标记
            visualization_msgs::Marker marker;
            marker.header = cloud_msg->header;
            marker.ns = "cylinder";
            marker.id = 0;
            marker.action = visualization_msgs::Marker::DELETE;
            cylinder_marker_pub_.publish(marker);

            ROS_INFO("No cylinder detected");
            ROS_INFO("- Possible reasons: insufficient point cloud quality or cylinder not in view");
            ROS_INFO("- Current height filter range: 0.0 ~ %.2f meters", CYLINDER_HEIGHT + HEIGHT_TOLERANCE);
            ROS_INFO("- Current radius search range: %.2f ~ %.2f meters", 
                     CYLINDER_RADIUS - RADIUS_TOLERANCE, 
                     CYLINDER_RADIUS + RADIUS_TOLERANCE);
        }
        ROS_INFO("----------------------------------------");
    }
};

int main(int argc, char** argv) {
    // 设置环境变量，确保使用UTF-8编码
    setenv("LANG", "en_US.UTF-8", 1);
    setenv("LC_ALL", "en_US.UTF-8", 1);
    
    ros::init(argc, argv, "cylinder_detector");
    CylinderDetector detector;
    ros::spin();
    return 0;
} 
