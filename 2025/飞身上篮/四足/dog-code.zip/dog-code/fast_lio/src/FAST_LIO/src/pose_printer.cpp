#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <tf/tf.h>

void odomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
    // 获取位置
    double x = msg->pose.pose.position.x;
    double y = msg->pose.pose.position.y;
    double z = msg->pose.pose.position.z;

    // 获取姿态四元数
    double qx = msg->pose.pose.orientation.x;
    double qy = msg->pose.pose.orientation.y;
    double qz = msg->pose.pose.orientation.z;
    double qw = msg->pose.pose.orientation.w;

    // 将四元数转换为欧拉角
    tf::Quaternion q(qx, qy, qz, qw);
    tf::Matrix3x3 m(q);
    double roll, pitch, yaw;
    m.getRPY(roll, pitch, yaw);

    // 转换为角度
    roll = roll * 180.0 / M_PI;
    pitch = pitch * 180.0 / M_PI;
    yaw = yaw * 180.0 / M_PI;

    // 打印位姿信息
    ROS_INFO("Position: [%.3f, %.3f, %.3f]", x, y, z);
    ROS_INFO("Orientation (RPY in degrees): [%.3f, %.3f, %.3f]", roll, pitch, yaw);
    ROS_INFO("----------------------------------------");
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "pose_printer");
    ros::NodeHandle nh;

    // 订阅Odometry话题
    ros::Subscriber sub = nh.subscribe("/Odometry", 10, odomCallback);

    ROS_INFO("开始监听位姿信息...");
    ros::spin();

    return 0;
} 