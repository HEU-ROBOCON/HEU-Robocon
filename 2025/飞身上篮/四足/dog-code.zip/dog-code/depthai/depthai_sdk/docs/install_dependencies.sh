#!/bin/bash

python3 -m pip install -r requirements.txt