DepthAI SDK is available on PyPI. You can install it with the following command:

.. code-block:: sh

   # Linux and macOS
   python3 -m pip install depthai-sdk

   # Windows
    py -m pip install depthai-sdk
