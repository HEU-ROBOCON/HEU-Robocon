.. raw:: html

   <h2>Got questions?</h2>

   Head over to <a href="https://discuss.luxonis.com/"><strong>Discussion Forum</strong></a> for technical support or any other questions you might have.
|
