Color camera example
=====================