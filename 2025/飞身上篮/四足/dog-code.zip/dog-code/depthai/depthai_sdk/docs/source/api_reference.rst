API Reference
=============

.. automodule:: depthai_sdk
    :autosummary:
    :members:
    :special-members: __init__
    :show-inheritance:
    :undoc-members:
    :imported-members:
