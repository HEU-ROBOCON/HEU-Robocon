import depthai as dai
import numpy as np


# def decode(data: dai.NNData) -> np.ndarray:
#     # TODO: Use standarized recognition model
#     return data.getData()
